import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { Alert, FlatList, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { RoleBadge } from '@/components/RoleBadge';
import { useAuth } from '@/context/AuthContext';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';
import { Reply } from '@/types';

export default function DebateDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { debates, replies, addReply, isDebateMember, requestMembership, membershipRequests } = useAppData();
  const [replyText, setReplyText] = useState('');

  const debate = debates.find(d => d.id === id);
  const debateReplies = replies.filter(r => r.debateId === id);
  const isMember = user ? (debate?.type === 'publico' || isDebateMember(id, user.id)) : false;
  const hasPending = user ? membershipRequests.some(r => r.debateId === id && r.userId === user.id && r.status === 'pendente') : false;

  if (!debate) {
    return (
      <View style={[styles.notFound, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.foreground }}>Debate não encontrado</Text>
      </View>
    );
  }

  function handleSendReply() {
    if (!replyText.trim() || !user) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    addReply(id, user.id, user.name, user.role, replyText.trim());
    setReplyText('');
  }

  function handleJoinRequest() {
    if (!user) return;
    requestMembership(id, debate.title, user.id, user.name);
    Alert.alert('Solicitação Enviada', 'O moderador analisará o seu pedido de entrada.');
  }

  function renderReply({ item }: { item: Reply }) {
    return (
      <View style={[styles.replyCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
        <View style={styles.replyHeader}>
          <View style={[styles.replyAvatar, { backgroundColor: colors.primary, borderRadius: 16 }]}>
            <Text style={styles.replyAvatarText}>{item.userName.charAt(0)}</Text>
          </View>
          <View style={styles.replyMeta}>
            <Text style={[styles.replyAuthor, { color: colors.foreground }]}>{item.userName}</Text>
            <Text style={[styles.replyDate, { color: colors.mutedForeground }]}>{new Date(item.createdAt).toLocaleDateString('pt-AO')}</Text>
          </View>
          <RoleBadge role={item.userRole} />
        </View>
        <Text style={[styles.replyContent, { color: colors.foreground }]}>{item.content}</Text>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 12, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]} numberOfLines={1}>Debate</Text>
        <View style={[styles.typeBadge, { backgroundColor: debate.type === 'publico' ? '#1A3A20' : '#3A1A20', borderRadius: 8 }]}>
          <Feather name={debate.type === 'publico' ? 'globe' : 'lock'} size={12} color={debate.type === 'publico' ? '#2ECC71' : colors.primary} />
          <Text style={[styles.typeText, { color: debate.type === 'publico' ? '#2ECC71' : colors.primary }]}>
            {debate.type === 'publico' ? 'Público' : 'Privado'}
          </Text>
        </View>
      </View>

      <FlatList
        data={debateReplies}
        keyExtractor={item => item.id}
        renderItem={renderReply}
        contentContainerStyle={{ padding: 20, paddingBottom: insets.bottom + 100 }}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View>
            <View style={[styles.questionCard, { backgroundColor: colors.card, borderColor: `${colors.primary}44`, borderRadius: colors.radius }]}>
              <View style={styles.questionMeta}>
                <View style={[styles.catBadge, { backgroundColor: colors.muted, borderRadius: 6 }]}>
                  <Text style={[styles.catText, { color: colors.mutedForeground }]}>{debate.category}</Text>
                </View>
                <Text style={[styles.questionDate, { color: colors.mutedForeground }]}>{new Date(debate.createdAt).toLocaleDateString('pt-AO')}</Text>
              </View>
              <Text style={[styles.questionTitle, { color: colors.foreground }]}>{debate.title}</Text>
              <Text style={[styles.questionDesc, { color: colors.mutedForeground }]}>{debate.description}</Text>
              <View style={styles.questionFooter}>
                <Text style={[styles.creator, { color: colors.mutedForeground }]}>por {debate.creatorName}</Text>
                <View style={styles.statsPair}>
                  <View style={styles.statItem}>
                    <Feather name="users" size={13} color={colors.mutedForeground} />
                    <Text style={[styles.statText, { color: colors.mutedForeground }]}>{debate.membersCount}</Text>
                  </View>
                  <View style={styles.statItem}>
                    <Feather name="message-circle" size={13} color={colors.mutedForeground} />
                    <Text style={[styles.statText, { color: colors.mutedForeground }]}>{debate.repliesCount}</Text>
                  </View>
                </View>
              </View>
            </View>
            {!isMember && !hasPending && (
              <TouchableOpacity
                style={[styles.joinBtn, { backgroundColor: colors.primary, borderRadius: colors.radius, marginBottom: 16 }]}
                onPress={handleJoinRequest}
                activeOpacity={0.8}
              >
                <Feather name="user-plus" size={16} color="#fff" />
                <Text style={styles.joinBtnText}>Solicitar Entrada no Fórum</Text>
              </TouchableOpacity>
            )}
            {hasPending && (
              <View style={[styles.pendingNotice, { backgroundColor: '#1A3A20', borderRadius: colors.radius, marginBottom: 16 }]}>
                <Feather name="clock" size={14} color="#2ECC71" />
                <Text style={styles.pendingNoticeText}>Solicitação de entrada pendente</Text>
              </View>
            )}
            <Text style={[styles.repliesTitle, { color: colors.foreground }]}>{debateReplies.length} Resposta{debateReplies.length !== 1 ? 's' : ''}</Text>
          </View>
        }
        ListEmptyComponent={
          <View style={styles.emptyReplies}>
            <Feather name="message-circle" size={30} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Ainda não há respostas. Seja o primeiro!</Text>
          </View>
        }
      />

      {/* Reply Input */}
      {(isMember && !debate.isClosed) && (
        <View style={[styles.replyBar, { backgroundColor: colors.card, borderTopColor: colors.border, paddingBottom: insets.bottom + 8 }]}>
          <TextInput
            style={[styles.replyInput, { backgroundColor: colors.muted, borderColor: colors.border, borderRadius: colors.radius, color: colors.foreground }]}
            placeholder="Escreva a sua resposta..."
            placeholderTextColor={colors.mutedForeground}
            value={replyText}
            onChangeText={setReplyText}
            multiline
          />
          <TouchableOpacity
            style={[styles.sendBtn, { backgroundColor: replyText.trim() ? colors.primary : colors.muted, borderRadius: 10 }]}
            onPress={handleSendReply}
            disabled={!replyText.trim()}
          >
            <Feather name="send" size={18} color={replyText.trim() ? '#fff' : colors.mutedForeground} />
          </TouchableOpacity>
        </View>
      )}
      {debate.isClosed && (
        <View style={[styles.closedBar, { backgroundColor: '#3A2A1A', borderTopColor: colors.border, paddingBottom: insets.bottom + 8 }]}>
          <Feather name="lock" size={14} color="#E67E22" />
          <Text style={styles.closedText}>Este debate foi encerrado</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  notFound: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, paddingBottom: 14, borderBottomWidth: 1 },
  headerTitle: { flex: 1, fontSize: 17, fontFamily: 'Inter_700Bold' },
  typeBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 5 },
  typeText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  questionCard: { borderWidth: 1, padding: 16, marginBottom: 16 },
  questionMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  catBadge: { paddingHorizontal: 8, paddingVertical: 3 },
  catText: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  questionDate: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  questionTitle: { fontSize: 18, fontFamily: 'Inter_700Bold', lineHeight: 24, marginBottom: 8 },
  questionDesc: { fontSize: 14, fontFamily: 'Inter_400Regular', lineHeight: 20, marginBottom: 12 },
  questionFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  creator: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  statsPair: { flexDirection: 'row', gap: 12 },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statText: { fontSize: 12, fontFamily: 'Inter_500Medium' },
  joinBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 12 },
  joinBtnText: { color: '#fff', fontSize: 14, fontFamily: 'Inter_700Bold' },
  pendingNotice: { flexDirection: 'row', alignItems: 'center', gap: 8, padding: 12 },
  pendingNoticeText: { color: '#2ECC71', fontSize: 13, fontFamily: 'Inter_500Medium' },
  repliesTitle: { fontSize: 16, fontFamily: 'Inter_700Bold', marginBottom: 12 },
  replyCard: { borderWidth: 1, padding: 14, marginBottom: 10 },
  replyHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  replyAvatar: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  replyAvatarText: { color: '#fff', fontSize: 13, fontFamily: 'Inter_700Bold' },
  replyMeta: { flex: 1 },
  replyAuthor: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  replyDate: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  replyContent: { fontSize: 14, fontFamily: 'Inter_400Regular', lineHeight: 20 },
  emptyReplies: { alignItems: 'center', gap: 10, paddingVertical: 30 },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', textAlign: 'center' },
  replyBar: { flexDirection: 'row', alignItems: 'flex-end', gap: 10, padding: 12, borderTopWidth: 1 },
  replyInput: { flex: 1, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, fontFamily: 'Inter_400Regular', maxHeight: 100 },
  sendBtn: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  closedBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, padding: 14, borderTopWidth: 1 },
  closedText: { color: '#E67E22', fontSize: 13, fontFamily: 'Inter_500Medium' },
});
