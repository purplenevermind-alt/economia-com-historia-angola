import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/context/AuthContext';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

const CATEGORIES = ['Historia', 'Economia', 'Geral', 'Cultura', 'Política'];

export default function CriarDebateScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { createDebate } = useAppData();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Geral');
  const [type, setType] = useState<'publico' | 'privado'>('publico');

  function handlePublish() {
    if (!title.trim() || !description.trim()) {
      Alert.alert('Campos obrigatórios', 'Por favor preencha o título e a descrição.');
      return;
    }
    if (!user) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    createDebate(title.trim(), description.trim(), category, type, user.id, user.name);
    Alert.alert('Debate Criado', 'O seu debate foi publicado com sucesso!', [
      { text: 'Ok', onPress: () => router.replace('/(tabs)/debates') }
    ]);
  }

  return (
    <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={[styles.header, { paddingTop: insets.top + 12, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="x" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Criar Debate</Text>
        <TouchableOpacity
          style={[styles.publishBtn, { backgroundColor: title.trim() && description.trim() ? colors.primary : colors.muted, borderRadius: 8 }]}
          onPress={handlePublish}
        >
          <Text style={[styles.publishBtnText, { color: title.trim() && description.trim() ? '#fff' : colors.mutedForeground }]}>Publicar</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={[styles.scroll, { paddingBottom: insets.bottom + 24 }]} keyboardShouldPersistTaps="handled">
        {/* Type selector */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Tipo de Fórum</Text>
        <View style={styles.typeRow}>
          {(['publico', 'privado'] as const).map(t => (
            <TouchableOpacity
              key={t}
              style={[styles.typeBtn, {
                backgroundColor: type === t ? colors.primary : colors.card,
                borderColor: type === t ? colors.primary : colors.border,
                borderRadius: colors.radius,
                flex: 1,
              }]}
              onPress={() => setType(t)}
            >
              <Feather name={t === 'publico' ? 'globe' : 'lock'} size={16} color={type === t ? '#fff' : colors.mutedForeground} />
              <View>
                <Text style={[styles.typeBtnLabel, { color: type === t ? '#fff' : colors.foreground }]}>
                  {t === 'publico' ? 'Público' : 'Privado'}
                </Text>
                <Text style={[styles.typeBtnSub, { color: type === t ? 'rgba(255,255,255,0.7)' : colors.mutedForeground }]}>
                  {t === 'publico' ? 'Qualquer utilizador pode participar' : 'Apenas membros autorizados'}
                </Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Category */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Categoria</Text>
        <View style={styles.catGrid}>
          {CATEGORIES.map(cat => (
            <TouchableOpacity
              key={cat}
              style={[styles.catBtn, {
                backgroundColor: category === cat ? `${colors.primary}22` : colors.card,
                borderColor: category === cat ? colors.primary : colors.border,
                borderRadius: 20,
              }]}
              onPress={() => setCategory(cat)}
            >
              <Text style={[styles.catBtnText, { color: category === cat ? colors.primary : colors.mutedForeground }]}>
                {cat === 'Historia' ? 'História' : cat}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Title */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Título *</Text>
        <TextInput
          style={[styles.titleInput, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius, color: colors.foreground }]}
          placeholder="Escreva um título claro e descritivo..."
          placeholderTextColor={colors.mutedForeground}
          value={title}
          onChangeText={setTitle}
          maxLength={120}
          multiline
        />
        <Text style={[styles.charCount, { color: colors.mutedForeground }]}>{title.length}/120</Text>

        {/* Description */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Descrição *</Text>
        <TextInput
          style={[styles.descInput, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius, color: colors.foreground }]}
          placeholder="Descreva o debate em detalhe. Qual é o contexto? O que pretende discutir?"
          placeholderTextColor={colors.mutedForeground}
          value={description}
          onChangeText={setDescription}
          multiline
          textAlignVertical="top"
          maxLength={1000}
        />
        <Text style={[styles.charCount, { color: colors.mutedForeground }]}>{description.length}/1000</Text>

        {type === 'privado' && (
          <View style={[styles.infoBox, { backgroundColor: '#1E2A3A', borderColor: '#1E6AB022', borderRadius: colors.radius }]}>
            <Feather name="info" size={16} color={colors.secondary} />
            <Text style={[styles.infoText, { color: colors.secondary }]}>
              Como criador de um fórum privado, tornar-se-á moderador. Poderá convidar participantes, gerir entradas e encerrar discussões.
            </Text>
          </View>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 14, borderBottomWidth: 1, gap: 12 },
  headerTitle: { flex: 1, fontSize: 17, fontFamily: 'Inter_700Bold' },
  publishBtn: { paddingHorizontal: 16, paddingVertical: 8 },
  publishBtnText: { fontSize: 14, fontFamily: 'Inter_700Bold' },
  scroll: { padding: 20 },
  sectionLabel: { fontSize: 12, fontFamily: 'Inter_700Bold', letterSpacing: 0.8, textTransform: 'uppercase', marginBottom: 10, marginTop: 20 },
  typeRow: { flexDirection: 'row', gap: 10 },
  typeBtn: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14, borderWidth: 1 },
  typeBtnLabel: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  typeBtnSub: { fontSize: 11, fontFamily: 'Inter_400Regular', marginTop: 2, maxWidth: 120 },
  catGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  catBtn: { paddingHorizontal: 14, paddingVertical: 8, borderWidth: 1 },
  catBtnText: { fontSize: 13, fontFamily: 'Inter_500Medium' },
  titleInput: { borderWidth: 1, padding: 14, fontSize: 15, fontFamily: 'Inter_400Regular', lineHeight: 22, minHeight: 60 },
  charCount: { fontSize: 11, fontFamily: 'Inter_400Regular', textAlign: 'right', marginTop: 4 },
  descInput: { borderWidth: 1, padding: 14, fontSize: 14, fontFamily: 'Inter_400Regular', lineHeight: 21, minHeight: 140 },
  infoBox: { flexDirection: 'row', gap: 10, padding: 14, borderWidth: 1, marginTop: 16 },
  infoText: { flex: 1, fontSize: 13, fontFamily: 'Inter_400Regular', lineHeight: 19 },
});
