import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function RegisterScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { register } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleRegister() {
    if (!name.trim() || !email.trim() || !password || !confirm) {
      Alert.alert('Campos obrigatórios', 'Por favor preencha todos os campos.');
      return;
    }
    if (password !== confirm) {
      Alert.alert('Erro', 'As palavras-passe não coincidem.');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Erro', 'A palavra-passe deve ter pelo menos 6 caracteres.');
      return;
    }
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const result = await register(name.trim(), email.trim(), password);
    setLoading(false);
    if (result.success) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace('/(tabs)');
    } else {
      Alert.alert('Erro', result.error ?? 'Não foi possível criar a conta.');
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient colors={['#1B0A14', '#14161D']} style={StyleSheet.absoluteFill} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={[styles.scroll, { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 24 }]} keyboardShouldPersistTaps="handled">
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <Feather name="arrow-left" size={22} color={colors.foreground} />
          </TouchableOpacity>

          <Text style={[styles.title, { color: colors.foreground }]}>Criar Conta</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Junte-se à comunidade angolana de aprendizagem</Text>

          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius + 4, marginTop: 24 }]}>
            {[
              { label: 'Nome completo', value: name, onChange: setName, placeholder: 'O seu nome', icon: 'user', type: 'default' as const },
              { label: 'Email', value: email, onChange: setEmail, placeholder: 'o-seu@email.com', icon: 'mail', type: 'email-address' as const },
            ].map(field => (
              <View key={field.label} style={styles.fieldGroup}>
                <Text style={[styles.label, { color: colors.mutedForeground }]}>{field.label}</Text>
                <View style={[styles.inputWrap, { backgroundColor: colors.muted, borderColor: colors.border, borderRadius: colors.radius }]}>
                  <Feather name={field.icon as any} size={18} color={colors.mutedForeground} />
                  <TextInput
                    style={[styles.input, { color: colors.foreground }]}
                    placeholder={field.placeholder}
                    placeholderTextColor={colors.mutedForeground}
                    value={field.value}
                    onChangeText={field.onChange}
                    autoCapitalize={field.type === 'default' ? 'words' : 'none'}
                    keyboardType={field.type}
                    autoCorrect={false}
                  />
                </View>
              </View>
            ))}

            {[
              { label: 'Palavra-passe', value: password, onChange: setPassword, placeholder: 'Mínimo 6 caracteres' },
              { label: 'Confirmar palavra-passe', value: confirm, onChange: setConfirm, placeholder: 'Repita a palavra-passe' },
            ].map(field => (
              <View key={field.label} style={styles.fieldGroup}>
                <Text style={[styles.label, { color: colors.mutedForeground }]}>{field.label}</Text>
                <View style={[styles.inputWrap, { backgroundColor: colors.muted, borderColor: colors.border, borderRadius: colors.radius }]}>
                  <Feather name="lock" size={18} color={colors.mutedForeground} />
                  <TextInput
                    style={[styles.input, { color: colors.foreground }]}
                    placeholder={field.placeholder}
                    placeholderTextColor={colors.mutedForeground}
                    value={field.value}
                    onChangeText={field.onChange}
                    secureTextEntry={!showPass}
                  />
                  {field.label === 'Palavra-passe' && (
                    <TouchableOpacity onPress={() => setShowPass(v => !v)}>
                      <Feather name={showPass ? 'eye-off' : 'eye'} size={18} color={colors.mutedForeground} />
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            ))}

            <TouchableOpacity
              style={[styles.createBtn, { backgroundColor: colors.primary, borderRadius: colors.radius, opacity: loading ? 0.7 : 1, marginTop: 8 }]}
              onPress={handleRegister}
              activeOpacity={0.8}
              disabled={loading}
            >
              <Text style={styles.createBtnText}>{loading ? 'A criar conta...' : 'Criar Conta'}</Text>
              {!loading && <Feather name="check" size={18} color="#fff" />}
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={styles.loginLink} onPress={() => router.back()}>
            <Text style={[styles.loginLinkText, { color: colors.mutedForeground }]}>
              Já tem conta? <Text style={{ color: colors.primary, fontFamily: 'Inter_600SemiBold' }}>Iniciar sessão</Text>
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { padding: 24 },
  backBtn: { marginBottom: 20, width: 40 },
  title: { fontSize: 28, fontFamily: 'Inter_700Bold' },
  subtitle: { fontSize: 14, fontFamily: 'Inter_400Regular', marginTop: 6, lineHeight: 20 },
  card: { borderWidth: 1, padding: 24 },
  fieldGroup: { marginBottom: 16 },
  label: { fontSize: 13, fontFamily: 'Inter_500Medium', marginBottom: 8 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, paddingHorizontal: 14, paddingVertical: 13, gap: 10 },
  input: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular' },
  createBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 15 },
  createBtnText: { color: '#fff', fontSize: 16, fontFamily: 'Inter_700Bold' },
  loginLink: { alignItems: 'center', marginTop: 20 },
  loginLinkText: { fontSize: 14, fontFamily: 'Inter_400Regular' },
});
