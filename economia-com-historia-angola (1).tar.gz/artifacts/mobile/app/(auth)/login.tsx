import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Image, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleLogin() {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Campos obrigatórios', 'Por favor preencha todos os campos.');
      return;
    }
    setLoading(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    const result = await login(email.trim(), password);
    setLoading(false);
    if (result.success) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.replace('/(tabs)');
    } else {
      Alert.alert('Erro', result.error ?? 'Não foi possível iniciar sessão.');
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient colors={['#1B0A14', '#14161D']} style={StyleSheet.absoluteFill} />

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={[styles.scroll, { paddingTop: insets.top + 40, paddingBottom: insets.bottom + 24 }]} keyboardShouldPersistTaps="handled">
          <View style={styles.header}>
            <Image source={require('@/assets/images/icon.png')} style={styles.logo} resizeMode="contain" />
            <Text style={[styles.appName, { color: colors.foreground }]}>Economia com História</Text>
            <Text style={[styles.appSub, { color: colors.primary }]}>Angola</Text>
          </View>

          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius + 4 }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Iniciar Sessão</Text>
            <Text style={[styles.cardSub, { color: colors.mutedForeground }]}>Aceda à sua conta para continuar</Text>

            <View style={styles.fieldGroup}>
              <Text style={[styles.label, { color: colors.mutedForeground }]}>Email</Text>
              <View style={[styles.inputWrap, { backgroundColor: colors.muted, borderColor: colors.border, borderRadius: colors.radius }]}>
                <Feather name="mail" size={18} color={colors.mutedForeground} />
                <TextInput
                  style={[styles.input, { color: colors.foreground }]}
                  placeholder="o-seu@email.com"
                  placeholderTextColor={colors.mutedForeground}
                  value={email}
                  onChangeText={setEmail}
                  autoCapitalize="none"
                  keyboardType="email-address"
                  autoCorrect={false}
                />
              </View>
            </View>

            <View style={styles.fieldGroup}>
              <Text style={[styles.label, { color: colors.mutedForeground }]}>Palavra-passe</Text>
              <View style={[styles.inputWrap, { backgroundColor: colors.muted, borderColor: colors.border, borderRadius: colors.radius }]}>
                <Feather name="lock" size={18} color={colors.mutedForeground} />
                <TextInput
                  style={[styles.input, { color: colors.foreground }]}
                  placeholder="A sua palavra-passe"
                  placeholderTextColor={colors.mutedForeground}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPass}
                />
                <TouchableOpacity onPress={() => setShowPass(v => !v)}>
                  <Feather name={showPass ? 'eye-off' : 'eye'} size={18} color={colors.mutedForeground} />
                </TouchableOpacity>
              </View>
            </View>

            <TouchableOpacity style={styles.forgotLink} activeOpacity={0.7}>
              <Text style={[styles.forgotText, { color: colors.primary }]}>Esqueci a palavra-passe</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.loginBtn, { backgroundColor: colors.primary, borderRadius: colors.radius, opacity: loading ? 0.7 : 1 }]}
              onPress={handleLogin}
              activeOpacity={0.8}
              disabled={loading}
            >
              <Text style={styles.loginBtnText}>{loading ? 'A entrar...' : 'Entrar'}</Text>
              {!loading && <Feather name="arrow-right" size={18} color="#fff" />}
            </TouchableOpacity>

            <View style={styles.divider}>
              <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
              <Text style={[styles.dividerText, { color: colors.mutedForeground }]}>ou</Text>
              <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
            </View>

            <TouchableOpacity
              style={[styles.registerBtn, { borderColor: colors.border, borderRadius: colors.radius }]}
              onPress={() => router.push('/(auth)/register')}
              activeOpacity={0.8}
            >
              <Text style={[styles.registerBtnText, { color: colors.foreground }]}>Criar Conta</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.demoBox}>
            <Text style={[styles.demoTitle, { color: colors.mutedForeground }]}>Contas de demonstração:</Text>
            {[
              { label: 'Super Admin', email: 'super@ecomhistoria.ao', pass: 'super123' },
              { label: 'Admin', email: 'admin@ecomhistoria.ao', pass: 'admin123' },
              { label: 'Utilizador', email: 'joao@email.com', pass: '123456' },
            ].map(acc => (
              <TouchableOpacity key={acc.email} onPress={() => { setEmail(acc.email); setPassword(acc.pass); }}>
                <Text style={[styles.demoItem, { color: colors.primary }]}>{acc.label}: {acc.email}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { padding: 24 },
  header: { alignItems: 'center', marginBottom: 32 },
  logo: { width: 80, height: 80, borderRadius: 20, marginBottom: 12 },
  appName: { fontSize: 22, fontFamily: 'Inter_700Bold', textAlign: 'center' },
  appSub: { fontSize: 16, fontFamily: 'Inter_600SemiBold', marginTop: 2 },
  card: { borderWidth: 1, padding: 24 },
  cardTitle: { fontSize: 22, fontFamily: 'Inter_700Bold', marginBottom: 6 },
  cardSub: { fontSize: 14, fontFamily: 'Inter_400Regular', marginBottom: 24 },
  fieldGroup: { marginBottom: 16 },
  label: { fontSize: 13, fontFamily: 'Inter_500Medium', marginBottom: 8 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, paddingHorizontal: 14, paddingVertical: 13, gap: 10 },
  input: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular' },
  forgotLink: { alignSelf: 'flex-end', marginBottom: 20, marginTop: -4 },
  forgotText: { fontSize: 13, fontFamily: 'Inter_500Medium' },
  loginBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 15 },
  loginBtnText: { color: '#fff', fontSize: 16, fontFamily: 'Inter_700Bold' },
  divider: { flexDirection: 'row', alignItems: 'center', gap: 12, marginVertical: 20 },
  dividerLine: { flex: 1, height: 1 },
  dividerText: { fontSize: 13, fontFamily: 'Inter_400Regular' },
  registerBtn: { borderWidth: 1, paddingVertical: 14, alignItems: 'center' },
  registerBtnText: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  demoBox: { marginTop: 24, padding: 16 },
  demoTitle: { fontSize: 12, fontFamily: 'Inter_500Medium', marginBottom: 8 },
  demoItem: { fontSize: 12, fontFamily: 'Inter_400Regular', marginBottom: 4 },
});
