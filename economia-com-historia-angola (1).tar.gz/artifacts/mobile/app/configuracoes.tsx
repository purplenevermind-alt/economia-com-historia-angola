import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, ScrollView, StyleSheet, Switch, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function ConfiguracoesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [notificacoesAtivas, setNotificacoesAtivas] = useState(true);
  const [debatesAtivos, setDebatesAtivos] = useState(true);
  const [quizzesAtivos, setQuizzesAtivos] = useState(false);

  const SECTIONS = [
    {
      title: 'Notificações',
      items: [
        { label: 'Notificações gerais', sub: 'Receber avisos importantes da plataforma', value: notificacoesAtivas, onChange: setNotificacoesAtivas },
        { label: 'Novos debates', sub: 'Ser notificado de novos fóruns', value: debatesAtivos, onChange: setDebatesAtivos },
        { label: 'Resultados de quizzes', sub: 'Comparações com outros utilizadores', value: quizzesAtivos, onChange: setQuizzesAtivos },
      ],
    },
  ];

  const MENU_SECTION = [
    { label: 'Sobre a Aplicação', icon: 'info', onPress: () => Alert.alert('Economia com História - Angola', 'Versão 1.0.0\n\nPlataforma educativa sobre História e Economia de Angola.\n\n© 2026 Economia com História - Angola') },
    { label: 'Política de Privacidade', icon: 'shield', onPress: () => Alert.alert('Privacidade', 'A sua privacidade é importante para nós. Todos os dados são armazenados de forma segura.') },
    { label: 'Termos de Uso', icon: 'file-text', onPress: () => Alert.alert('Termos de Uso', 'Ao utilizar esta aplicação, concorda com os nossos termos e condições de uso.') },
    { label: 'Contato / Suporte', icon: 'mail', onPress: () => Alert.alert('Suporte', 'Para suporte, contacte: suporte@ecomhistoria.ao') },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>Configurações</Text>
        <View style={{ width: 22 }} />
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 40 }} showsVerticalScrollIndicator={false}>
        {/* Profile quick view */}
        {user && (
          <View style={[styles.profileCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.profileAvatar, { backgroundColor: colors.primary, borderRadius: 28 }]}>
              <Text style={styles.profileAvatarText}>{user.name.charAt(0)}</Text>
            </View>
            <View style={styles.profileInfo}>
              <Text style={[styles.profileName, { color: colors.foreground }]}>{user.name}</Text>
              <Text style={[styles.profileEmail, { color: colors.mutedForeground }]}>{user.email}</Text>
            </View>
          </View>
        )}

        {/* Notification toggles */}
        {SECTIONS.map((section, sIdx) => (
          <View key={sIdx} style={styles.section}>
            <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>{section.title}</Text>
            <View style={[styles.sectionCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
              {section.items.map((item, iIdx) => (
                <View key={iIdx} style={[styles.toggleItem, iIdx < section.items.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}>
                  <View style={styles.toggleLabels}>
                    <Text style={[styles.toggleLabel, { color: colors.foreground }]}>{item.label}</Text>
                    <Text style={[styles.toggleSub, { color: colors.mutedForeground }]}>{item.sub}</Text>
                  </View>
                  <Switch
                    value={item.value}
                    onValueChange={item.onChange}
                    trackColor={{ false: colors.muted, true: colors.primary }}
                    thumbColor="#fff"
                  />
                </View>
              ))}
            </View>
          </View>
        ))}

        {/* App info menu */}
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Informações</Text>
          <View style={[styles.sectionCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
            {MENU_SECTION.map((item, idx) => (
              <TouchableOpacity
                key={idx}
                style={[styles.menuItem, idx < MENU_SECTION.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}
                onPress={item.onPress}
                activeOpacity={0.7}
              >
                <View style={[styles.menuIcon, { backgroundColor: colors.muted, borderRadius: 8 }]}>
                  <Feather name={item.icon as any} size={16} color={colors.mutedForeground} />
                </View>
                <Text style={[styles.menuLabel, { color: colors.foreground }]}>{item.label}</Text>
                <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <Text style={[styles.version, { color: colors.mutedForeground }]}>Versão 1.0.0 (2026)</Text>
        <Text style={[styles.version, { color: colors.mutedForeground, marginTop: 4 }]}>Economia com História - Angola</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1 },
  title: { fontSize: 20, fontFamily: 'Inter_700Bold' },
  profileCard: { flexDirection: 'row', alignItems: 'center', gap: 14, margin: 20, padding: 16, borderWidth: 1, borderRadius: 14 },
  profileAvatar: { width: 56, height: 56, alignItems: 'center', justifyContent: 'center' },
  profileAvatarText: { color: '#fff', fontSize: 22, fontFamily: 'Inter_700Bold' },
  profileInfo: { flex: 1 },
  profileName: { fontSize: 16, fontFamily: 'Inter_700Bold', marginBottom: 2 },
  profileEmail: { fontSize: 13, fontFamily: 'Inter_400Regular' },
  section: { paddingHorizontal: 20, marginBottom: 8 },
  sectionLabel: { fontSize: 11, fontFamily: 'Inter_700Bold', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 8 },
  sectionCard: { borderWidth: 1 },
  toggleItem: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  toggleLabels: { flex: 1 },
  toggleLabel: { fontSize: 15, fontFamily: 'Inter_500Medium' },
  toggleSub: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  menuIcon: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center' },
  menuLabel: { flex: 1, fontSize: 15, fontFamily: 'Inter_500Medium' },
  version: { textAlign: 'center', fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 20 },
});
