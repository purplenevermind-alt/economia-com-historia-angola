import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ContentCard } from '@/components/ContentCard';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

export default function FavoritosScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { contents, favorites } = useAppData();
  const favContents = contents.filter(c => favorites.includes(c.id));

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>Favoritos</Text>
        <View style={{ width: 22 }} />
      </View>
      <FlatList
        data={favContents}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <ContentCard content={item} isFavorite />}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="heart" size={48} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Sem favoritos ainda</Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Adicione conteúdos aos favoritos tocando no ícone de coração.</Text>
            <TouchableOpacity style={[styles.browseBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]} onPress={() => router.push('/(tabs)/conteudos' as any)}>
              <Text style={styles.browseBtnText}>Explorar Conteúdos</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1 },
  title: { fontSize: 20, fontFamily: 'Inter_700Bold' },
  list: { padding: 20, paddingBottom: 40 },
  empty: { alignItems: 'center', paddingTop: 80, paddingHorizontal: 40, gap: 12 },
  emptyTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', marginTop: 8 },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 20 },
  browseBtn: { paddingHorizontal: 24, paddingVertical: 12, marginTop: 8 },
  browseBtnText: { color: '#fff', fontSize: 15, fontFamily: 'Inter_600SemiBold' },
});
