import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { RoleBadge } from '@/components/RoleBadge';
import { useAuth } from '@/context/AuthContext';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';
import { UserRole } from '@/types';

const ROLES: UserRole[] = ['utilizador', 'moderador', 'administrador', 'super_administrador'];

export default function AdminUtilizadoresScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user: me } = useAuth();
  const { allUsers, changeUserRole, banUser } = useAppData();
  const [filter, setFilter] = useState<UserRole | 'Todos'>('Todos');

  const filtered = filter === 'Todos' ? allUsers : allUsers.filter(u => u.role === filter);

  const canManage = (targetRole: UserRole) => {
    if (!me) return false;
    if (me.role === 'super_administrador') return true;
    if (me.role === 'administrador') return targetRole === 'utilizador' || targetRole === 'moderador';
    return false;
  };

  function handleChangeRole(userId: string, currentRole: UserRole, targetName: string) {
    const nextRole = ROLES[(ROLES.indexOf(currentRole) + 1) % ROLES.length];
    Alert.alert(
      'Alterar Função',
      `Promover ${targetName} para ${nextRole.replace('_', ' ')}?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Confirmar', onPress: () => changeUserRole(userId, nextRole) },
      ]
    );
  }

  function handleBan(userId: string, targetName: string) {
    Alert.alert(
      'Banir Utilizador',
      `Tem a certeza que deseja banir ${targetName}? Esta ação remove o acesso à plataforma.`,
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Banir', style: 'destructive', onPress: () => banUser(userId) },
      ]
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>Utilizadores</Text>
        <Text style={[styles.count, { color: colors.mutedForeground }]}>{allUsers.length}</Text>
      </View>

      {/* Filter Tabs */}
      <View style={[styles.filterBar, { borderBottomColor: colors.border }]}>
        {(['Todos', ...ROLES] as const).map(r => (
          <TouchableOpacity
            key={r}
            style={[styles.filterTab, filter === r && { borderBottomWidth: 2, borderBottomColor: colors.primary }]}
            onPress={() => setFilter(r)}
          >
            <Text style={[styles.filterTabText, { color: filter === r ? colors.primary : colors.mutedForeground }]}>
              {r === 'super_administrador' ? 'Super' : r === 'administrador' ? 'Admin' : r === 'moderador' ? 'Mod' : r === 'utilizador' ? 'User' : 'Todos'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 40 }]}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={[styles.userCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
            <View style={styles.userTop}>
              <View style={[styles.avatar, { backgroundColor: colors.primary, borderRadius: 22 }]}>
                <Text style={styles.avatarText}>{item.name.charAt(0)}</Text>
              </View>
              <View style={styles.userInfo}>
                <Text style={[styles.userName, { color: colors.foreground }]}>{item.name}</Text>
                <Text style={[styles.userEmail, { color: colors.mutedForeground }]}>{item.email}</Text>
              </View>
              {item.role === 'super_administrador' && (
                <MaterialCommunityIcons name="shield-crown" size={18} color={colors.gold} />
              )}
            </View>
            <View style={styles.userMeta}>
              <RoleBadge role={item.role} />
              <Text style={[styles.joinDate, { color: colors.mutedForeground }]}>desde {new Date(item.createdAt).toLocaleDateString('pt-AO')}</Text>
              <View style={styles.pointsBadge}>
                <Feather name="star" size={11} color={colors.gold} />
                <Text style={[styles.pointsText, { color: colors.mutedForeground }]}>{item.pontuacaoTotal} pts</Text>
              </View>
            </View>
            {canManage(item.role) && item.id !== me?.id && (
              <View style={styles.actions}>
                <TouchableOpacity
                  style={[styles.actionBtn, { backgroundColor: `${colors.secondary}22`, borderRadius: 8 }]}
                  onPress={() => handleChangeRole(item.id, item.role, item.name)}
                >
                  <Feather name="arrow-up" size={13} color={colors.secondary} />
                  <Text style={[styles.actionBtnText, { color: colors.secondary }]}>Promover</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.actionBtn, { backgroundColor: `${colors.destructive}22`, borderRadius: 8 }]}
                  onPress={() => handleBan(item.id, item.name)}
                >
                  <Feather name="slash" size={13} color={colors.destructive} />
                  <Text style={[styles.actionBtnText, { color: colors.destructive }]}>Banir</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Nenhum utilizador encontrado</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, gap: 12 },
  title: { flex: 1, fontSize: 20, fontFamily: 'Inter_700Bold' },
  count: { fontSize: 14, fontFamily: 'Inter_500Medium' },
  filterBar: { flexDirection: 'row', borderBottomWidth: 1 },
  filterTab: { flex: 1, alignItems: 'center', paddingVertical: 12 },
  filterTabText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  list: { padding: 20 },
  userCard: { borderWidth: 1, padding: 14, marginBottom: 10 },
  userTop: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  avatar: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#fff', fontSize: 16, fontFamily: 'Inter_700Bold' },
  userInfo: { flex: 1 },
  userName: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  userEmail: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  userMeta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12, flexWrap: 'wrap' },
  joinDate: { fontSize: 11, fontFamily: 'Inter_400Regular', flex: 1 },
  pointsBadge: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  pointsText: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  actions: { flexDirection: 'row', gap: 8 },
  actionBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, paddingVertical: 8 },
  actionBtnText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  empty: { alignItems: 'center', paddingTop: 40 },
  emptyText: { fontSize: 14, fontFamily: 'Inter_500Medium' },
});
