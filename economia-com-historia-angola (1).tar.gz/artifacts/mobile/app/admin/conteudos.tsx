import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';
import { Content } from '@/types';

export default function AdminConteudosScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { contents, archiveContent, publishContent } = useAppData();
  const [filter, setFilter] = useState<'todos' | 'publico' | 'jindungo' | 'arquivado'>('todos');

  const filtered = filter === 'todos'
    ? contents
    : contents.filter(c => filter === 'arquivado' ? c.isArchived : c.type === filter && !c.isArchived);

  function handleArchive(item: Content) {
    Alert.alert(
      item.isArchived ? 'Restaurar Conteúdo' : 'Arquivar Conteúdo',
      item.isArchived
        ? `Restaurar "${item.title}" para publicação?`
        : `Arquivar "${item.title}"? Não ficará visível aos utilizadores.`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: item.isArchived ? 'Restaurar' : 'Arquivar',
          onPress: () => item.isArchived ? publishContent(item.id) : archiveContent(item.id),
        }
      ]
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>Conteúdos</Text>
        <Text style={[styles.count, { color: colors.mutedForeground }]}>{contents.length}</Text>
      </View>

      <View style={[styles.filterBar, { borderBottomColor: colors.border }]}>
        {[
          { key: 'todos', label: 'Todos' },
          { key: 'publico', label: 'Público' },
          { key: 'jindungo', label: 'Jindungo' },
          { key: 'arquivado', label: 'Arquivados' },
        ].map(f => (
          <TouchableOpacity
            key={f.key}
            style={[styles.filterTab, filter === f.key && { borderBottomWidth: 2, borderBottomColor: colors.primary }]}
            onPress={() => setFilter(f.key as any)}
          >
            <Text style={[styles.filterTabText, { color: filter === f.key ? colors.primary : colors.mutedForeground }]}>{f.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 40 }]}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={[styles.contentCard, { backgroundColor: colors.card, borderColor: item.isArchived ? colors.border : item.type === 'jindungo' ? `${colors.primary}44` : colors.border, borderRadius: colors.radius, opacity: item.isArchived ? 0.7 : 1 }]}>
            <View style={styles.cardTop}>
              <View style={styles.cardBadges}>
                <View style={[styles.typeBadge, { backgroundColor: item.category === 'Historia' ? '#1E3A5F' : '#2D1B33', borderRadius: 5 }]}>
                  <Text style={[styles.typeBadgeText, { color: item.category === 'Historia' ? '#5B9BD5' : '#B86CC8' }]}>
                    {item.category === 'Historia' ? 'História' : 'Economia'}
                  </Text>
                </View>
                <View style={[styles.typeBadge, { backgroundColor: item.type === 'jindungo' ? `${colors.primary}22` : `${colors.success}22`, borderRadius: 5 }]}>
                  <Text style={[styles.typeBadgeText, { color: item.type === 'jindungo' ? colors.primary : colors.success }]}>
                    {item.type === 'jindungo' ? 'Jindungo' : 'Público'}
                  </Text>
                </View>
                {item.isArchived && (
                  <View style={[styles.typeBadge, { backgroundColor: '#333', borderRadius: 5 }]}>
                    <Text style={[styles.typeBadgeText, { color: colors.mutedForeground }]}>Arquivado</Text>
                  </View>
                )}
              </View>
              <TouchableOpacity
                style={[styles.archiveBtn, { backgroundColor: item.isArchived ? `${colors.success}22` : '#33201A', borderRadius: 7 }]}
                onPress={() => handleArchive(item)}
              >
                <Feather name={item.isArchived ? 'upload' : 'archive'} size={14} color={item.isArchived ? colors.success : '#E67E22'} />
              </TouchableOpacity>
            </View>
            <Text style={[styles.contentTitle, { color: colors.foreground }]} numberOfLines={2}>{item.title}</Text>
            <Text style={[styles.contentMeta, { color: colors.mutedForeground }]}>por {item.author} · {item.views.toLocaleString()} visualizações</Text>
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Nenhum conteúdo encontrado</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, gap: 12 },
  title: { flex: 1, fontSize: 20, fontFamily: 'Inter_700Bold' },
  count: { fontSize: 14, fontFamily: 'Inter_500Medium' },
  filterBar: { flexDirection: 'row', borderBottomWidth: 1 },
  filterTab: { flex: 1, alignItems: 'center', paddingVertical: 12 },
  filterTabText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  list: { padding: 20, gap: 10 },
  contentCard: { borderWidth: 1, padding: 14 },
  cardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  cardBadges: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  typeBadge: { paddingHorizontal: 7, paddingVertical: 3 },
  typeBadgeText: { fontSize: 10, fontFamily: 'Inter_600SemiBold' },
  archiveBtn: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  contentTitle: { fontSize: 14, fontFamily: 'Inter_600SemiBold', lineHeight: 20, marginBottom: 6 },
  contentMeta: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  empty: { alignItems: 'center', paddingTop: 40 },
  emptyText: { fontSize: 14, fontFamily: 'Inter_500Medium' },
});
