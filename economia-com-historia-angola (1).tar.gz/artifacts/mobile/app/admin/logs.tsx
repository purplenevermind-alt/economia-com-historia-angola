import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';
import { AdminLog } from '@/types';

const LOG_ICONS: Record<string, string> = {
  'aprovacao_jindungo': 'star',
  'rejeicao_jindungo': 'x-circle',
  'aprovacao_membro': 'user-check',
  'rejeicao_membro': 'user-x',
  'promocao_utilizador': 'arrow-up',
  'ban_utilizador': 'slash',
  'encerrar_debate': 'lock',
  'arquivar_conteudo': 'archive',
  'restaurar_conteudo': 'upload',
};

const LOG_COLORS: Record<string, string> = {
  'aprovacao_jindungo': '#2ECC71',
  'rejeicao_jindungo': '#E74C3C',
  'aprovacao_membro': '#2ECC71',
  'rejeicao_membro': '#E74C3C',
  'promocao_utilizador': '#1E6AB0',
  'ban_utilizador': '#E74C3C',
  'encerrar_debate': '#E67E22',
  'arquivar_conteudo': '#E67E22',
  'restaurar_conteudo': '#2ECC71',
};

const LOG_LABELS: Record<string, string> = {
  'aprovacao_jindungo': 'Acesso Jindungo Aprovado',
  'rejeicao_jindungo': 'Acesso Jindungo Rejeitado',
  'aprovacao_membro': 'Entrada em Fórum Aprovada',
  'rejeicao_membro': 'Entrada em Fórum Rejeitada',
  'promocao_utilizador': 'Utilizador Promovido',
  'ban_utilizador': 'Utilizador Banido',
  'encerrar_debate': 'Debate Encerrado',
  'arquivar_conteudo': 'Conteúdo Arquivado',
  'restaurar_conteudo': 'Conteúdo Restaurado',
};

export default function AdminLogsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { adminLogs } = useAppData();
  const [filter, setFilter] = useState<'todos' | 'aprovacoes' | 'rejeicoes' | 'outros'>('todos');

  const sorted = [...adminLogs].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const filtered = filter === 'todos' ? sorted
    : filter === 'aprovacoes' ? sorted.filter(l => l.action.startsWith('aprovacao'))
    : filter === 'rejeicoes' ? sorted.filter(l => l.action.startsWith('rejeicao') || l.action === 'ban_utilizador')
    : sorted.filter(l => !l.action.startsWith('aprovacao') && !l.action.startsWith('rejeicao') && l.action !== 'ban_utilizador');

  function renderLog({ item }: { item: AdminLog }) {
    const icon = LOG_ICONS[item.action] ?? 'activity';
    const logColor = LOG_COLORS[item.action] ?? colors.mutedForeground;
    const label = LOG_LABELS[item.action] ?? item.action;

    return (
      <View style={[styles.logCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
        <View style={[styles.logIconWrap, { backgroundColor: `${logColor}22`, borderRadius: 20 }]}>
          <Feather name={icon as any} size={14} color={logColor} />
        </View>
        <View style={styles.logContent}>
          <Text style={[styles.logAction, { color: colors.foreground }]}>{label}</Text>
          <Text style={[styles.logDetail, { color: colors.mutedForeground }]} numberOfLines={2}>{item.details}</Text>
          <View style={styles.logMeta}>
            <Text style={[styles.logAdmin, { color: colors.mutedForeground }]}>por {item.adminName}</Text>
            <Text style={[styles.logDate, { color: colors.mutedForeground }]}>{new Date(item.createdAt).toLocaleString('pt-AO', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</Text>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>Registos de Atividade</Text>
        <Text style={[styles.count, { color: colors.mutedForeground }]}>{adminLogs.length}</Text>
      </View>

      <View style={[styles.filterBar, { borderBottomColor: colors.border }]}>
        {[
          { key: 'todos', label: 'Todos' },
          { key: 'aprovacoes', label: 'Aprovações' },
          { key: 'rejeicoes', label: 'Rejeições' },
          { key: 'outros', label: 'Outros' },
        ].map(f => (
          <TouchableOpacity
            key={f.key}
            style={[styles.filterTab, filter === f.key && { borderBottomWidth: 2, borderBottomColor: colors.primary }]}
            onPress={() => setFilter(f.key as any)}
          >
            <Text style={[styles.filterTabText, { color: filter === f.key ? colors.primary : colors.mutedForeground }]}>{f.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        renderItem={renderLog}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 40 }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="activity" size={40} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Sem registos de atividade</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, gap: 12 },
  title: { flex: 1, fontSize: 18, fontFamily: 'Inter_700Bold' },
  count: { fontSize: 14, fontFamily: 'Inter_500Medium' },
  filterBar: { flexDirection: 'row', borderBottomWidth: 1 },
  filterTab: { flex: 1, alignItems: 'center', paddingVertical: 12 },
  filterTabText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  list: { padding: 20, gap: 8 },
  logCard: { flexDirection: 'row', gap: 12, borderWidth: 1, padding: 14 },
  logIconWrap: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 2 },
  logContent: { flex: 1 },
  logAction: { fontSize: 14, fontFamily: 'Inter_600SemiBold', marginBottom: 3 },
  logDetail: { fontSize: 12, fontFamily: 'Inter_400Regular', lineHeight: 17, marginBottom: 6 },
  logMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  logAdmin: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  logDate: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyText: { fontSize: 14, fontFamily: 'Inter_500Medium' },
});
