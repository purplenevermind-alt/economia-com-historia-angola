import { Feather } from '@expo/vector-icons';
import { router, Stack } from 'expo-router';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function AdminLayout() {
  const colors = useColors();
  const { isAdmin } = useAuth();

  if (!isAdmin) {
    return (
      <View style={[styles.denied, { backgroundColor: colors.background }]}>
        <Feather name="shield-off" size={48} color={colors.mutedForeground} />
        <Text style={[styles.deniedTitle, { color: colors.foreground }]}>Acesso Negado</Text>
        <Text style={[styles.deniedText, { color: colors.mutedForeground }]}>Não tem permissões para aceder ao painel administrativo.</Text>
        <TouchableOpacity style={[styles.backBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]} onPress={() => router.back()}>
          <Text style={styles.backBtnText}>Voltar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <Stack screenOptions={{ headerShown: false }} />
  );
}

const styles = StyleSheet.create({
  denied: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32, gap: 12 },
  deniedTitle: { fontSize: 22, fontFamily: 'Inter_700Bold', marginTop: 8 },
  deniedText: { fontSize: 14, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 20 },
  backBtn: { paddingHorizontal: 24, paddingVertical: 12, marginTop: 8 },
  backBtnText: { color: '#fff', fontSize: 15, fontFamily: 'Inter_600SemiBold' },
});
