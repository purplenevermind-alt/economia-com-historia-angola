import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

export default function AdminJindungoScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { jindungoRequests, approveJindungo, rejectJindungo, contents } = useAppData();
  const [filter, setFilter] = useState<'pendente' | 'aprovada' | 'rejeitada'>('pendente');

  const filtered = jindungoRequests.filter(r => r.status === filter);

  function getContentTitle(contentId: string) {
    return contents.find(c => c.id === contentId)?.title ?? 'Conteúdo desconhecido';
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <View style={styles.headerTitle}>
          <MaterialCommunityIcons name="star-four-points" size={18} color={colors.primary} />
          <Text style={[styles.title, { color: colors.foreground }]}>Jindungo</Text>
        </View>
        <View style={[styles.pendingCount, { backgroundColor: `${colors.primary}22`, borderRadius: 12 }]}>
          <Text style={[styles.pendingCountText, { color: colors.primary }]}>
            {jindungoRequests.filter(r => r.status === 'pendente').length} pendentes
          </Text>
        </View>
      </View>

      {/* Tabs */}
      <View style={[styles.tabs, { borderBottomColor: colors.border }]}>
        {([
          { key: 'pendente', label: 'Pendentes', color: '#E67E22' },
          { key: 'aprovada', label: 'Aprovados', color: colors.success },
          { key: 'rejeitada', label: 'Rejeitados', color: colors.destructive },
        ] as const).map(t => (
          <TouchableOpacity
            key={t.key}
            style={[styles.tab, filter === t.key && { borderBottomWidth: 2, borderBottomColor: t.color }]}
            onPress={() => setFilter(t.key)}
          >
            <Text style={[styles.tabText, { color: filter === t.key ? t.color : colors.mutedForeground }]}>
              {t.label} ({jindungoRequests.filter(r => r.status === (t.key as string)).length})
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 40 }]}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
            <View style={styles.cardHeader}>
              <View style={[styles.avatar, { backgroundColor: colors.primary, borderRadius: 20 }]}>
                <Text style={styles.avatarText}>{item.userName.charAt(0)}</Text>
              </View>
              <View style={styles.cardInfo}>
                <Text style={[styles.cardUser, { color: colors.foreground }]}>{item.userName}</Text>
                <Text style={[styles.cardDate, { color: colors.mutedForeground }]}>{new Date(item.requestedAt).toLocaleDateString('pt-AO')}</Text>
              </View>
              {item.status === 'pendente' && (
                <View style={[styles.statusPill, { backgroundColor: '#33251A', borderRadius: 12 }]}>
                  <Feather name="clock" size={11} color="#E67E22" />
                  <Text style={[styles.statusPillText, { color: '#E67E22' }]}>Pendente</Text>
                </View>
              )}
              {item.status === 'aprovada' && (
                <View style={[styles.statusPill, { backgroundColor: '#1A3A20', borderRadius: 12 }]}>
                  <Feather name="check" size={11} color={colors.success} />
                  <Text style={[styles.statusPillText, { color: colors.success }]}>Aprovado</Text>
                </View>
              )}
              {item.status === 'rejeitada' && (
                <View style={[styles.statusPill, { backgroundColor: '#3A1A1A', borderRadius: 12 }]}>
                  <Feather name="x" size={11} color={colors.destructive} />
                  <Text style={[styles.statusPillText, { color: colors.destructive }]}>Rejeitado</Text>
                </View>
              )}
            </View>

            <View style={[styles.contentRef, { backgroundColor: `${colors.primary}10`, borderRadius: 8 }]}>
              <MaterialCommunityIcons name="star-four-points" size={13} color={colors.primary} />
              <Text style={[styles.contentRefText, { color: colors.foreground }]} numberOfLines={1}>
                {getContentTitle(item.contentId)}
              </Text>
            </View>

            {item.status === 'pendente' && (
              <View style={styles.actions}>
                <TouchableOpacity
                  style={[styles.rejectBtn, { borderColor: colors.destructive, borderRadius: 8 }]}
                  onPress={() => rejectJindungo(item.id)}
                >
                  <Feather name="x" size={14} color={colors.destructive} />
                  <Text style={[styles.rejectBtnText, { color: colors.destructive }]}>Rejeitar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.approveBtn, { backgroundColor: colors.success, borderRadius: 8 }]}
                  onPress={() => approveJindungo(item.id)}
                >
                  <Feather name="check" size={14} color="#fff" />
                  <Text style={styles.approveBtnText}>Aprovar Acesso</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="star-four-points" size={40} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              {filter === 'pendente' ? 'Sem solicitações pendentes' : filter === 'aprovado' ? 'Nenhum acesso aprovado' : 'Nenhuma solicitação rejeitada'}
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, gap: 12 },
  headerTitle: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  title: { fontSize: 20, fontFamily: 'Inter_700Bold' },
  pendingCount: { paddingHorizontal: 10, paddingVertical: 4 },
  pendingCountText: { fontSize: 11, fontFamily: 'Inter_700Bold' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1 },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 12 },
  tabText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  list: { padding: 20, gap: 10 },
  card: { borderWidth: 1, padding: 14 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  avatar: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#fff', fontSize: 15, fontFamily: 'Inter_700Bold' },
  cardInfo: { flex: 1 },
  cardUser: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  cardDate: { fontSize: 11, fontFamily: 'Inter_400Regular', marginTop: 2 },
  statusPill: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4 },
  statusPillText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  contentRef: { flexDirection: 'row', alignItems: 'center', gap: 6, padding: 10, marginBottom: 12 },
  contentRefText: { flex: 1, fontSize: 13, fontFamily: 'Inter_500Medium' },
  actions: { flexDirection: 'row', gap: 8 },
  rejectBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderWidth: 1, paddingVertical: 10 },
  rejectBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  approveBtn: { flex: 2, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10 },
  approveBtnText: { color: '#fff', fontSize: 13, fontFamily: 'Inter_700Bold' },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyText: { fontSize: 14, fontFamily: 'Inter_500Medium', textAlign: 'center' },
});
