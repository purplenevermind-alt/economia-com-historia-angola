import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

export default function AdminForunsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { debates, membershipRequests, approveMembership, rejectMembership, closeDebate } = useAppData();
  const [view, setView] = useState<'debates' | 'requests'>('requests');

  const pendingRequests = membershipRequests.filter(r => r.status === 'pendente');

  function getDebateTitle(debateId: string) {
    return debates.find(d => d.id === debateId)?.title ?? 'Debate desconhecido';
  }

  function handleCloseDebate(debateId: string, title: string) {
    Alert.alert('Encerrar Debate', `Tem a certeza que deseja encerrar "${title}"? Não poderão ser adicionadas mais respostas.`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Encerrar', style: 'destructive', onPress: () => closeDebate(debateId) },
    ]);
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>Moderação de Fóruns</Text>
        {pendingRequests.length > 0 && (
          <View style={[styles.badge, { backgroundColor: colors.primary }]}>
            <Text style={styles.badgeText}>{pendingRequests.length}</Text>
          </View>
        )}
      </View>

      <View style={[styles.tabs, { borderBottomColor: colors.border }]}>
        <TouchableOpacity style={[styles.tab, view === 'requests' && { borderBottomWidth: 2, borderBottomColor: colors.primary }]} onPress={() => setView('requests')}>
          <Text style={[styles.tabText, { color: view === 'requests' ? colors.primary : colors.mutedForeground }]}>
            Pedidos ({pendingRequests.length})
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, view === 'debates' && { borderBottomWidth: 2, borderBottomColor: colors.primary }]} onPress={() => setView('debates')}>
          <Text style={[styles.tabText, { color: view === 'debates' ? colors.primary : colors.mutedForeground }]}>
            Debates ({debates.length})
          </Text>
        </TouchableOpacity>
      </View>

      {view === 'requests' ? (
        <FlatList
          data={pendingRequests}
          keyExtractor={item => item.id}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 40 }]}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
              <View style={styles.cardHeader}>
                <View style={[styles.avatar, { backgroundColor: colors.secondary, borderRadius: 18 }]}>
                  <Text style={styles.avatarText}>{item.userName.charAt(0)}</Text>
                </View>
                <View style={styles.cardInfo}>
                  <Text style={[styles.cardUser, { color: colors.foreground }]}>{item.userName}</Text>
                  <Text style={[styles.cardDate, { color: colors.mutedForeground }]}>{new Date(item.requestedAt).toLocaleDateString('pt-AO')}</Text>
                </View>
              </View>
              <View style={[styles.debateRef, { backgroundColor: colors.muted, borderRadius: 8 }]}>
                <Feather name="message-square" size={13} color={colors.mutedForeground} />
                <Text style={[styles.debateRefText, { color: colors.foreground }]} numberOfLines={1}>
                  {item.debateTitle}
                </Text>
              </View>
              <View style={styles.actions}>
                <TouchableOpacity
                  style={[styles.rejectBtn, { borderColor: colors.destructive, borderRadius: 8 }]}
                  onPress={() => rejectMembership(item.id)}
                >
                  <Feather name="x" size={14} color={colors.destructive} />
                  <Text style={[styles.rejectBtnText, { color: colors.destructive }]}>Rejeitar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.approveBtn, { backgroundColor: colors.success, borderRadius: 8 }]}
                  onPress={() => approveMembership(item.id)}
                >
                  <Feather name="check" size={14} color="#fff" />
                  <Text style={styles.approveBtnText}>Aprovar Entrada</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Feather name="check-circle" size={40} color={colors.success} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Sem pedidos de entrada pendentes</Text>
            </View>
          }
        />
      ) : (
        <FlatList
          data={debates}
          keyExtractor={item => item.id}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 40 }]}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={[styles.debateCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
              <View style={styles.debateCardTop}>
                <View style={styles.debateBadges}>
                  <View style={[styles.typePill, { backgroundColor: item.type === 'publico' ? '#1A3A20' : '#3A1A20', borderRadius: 6 }]}>
                    <Feather name={item.type === 'publico' ? 'globe' : 'lock'} size={11} color={item.type === 'publico' ? '#2ECC71' : colors.primary} />
                    <Text style={[styles.typePillText, { color: item.type === 'publico' ? '#2ECC71' : colors.primary }]}>
                      {item.type === 'publico' ? 'Público' : 'Privado'}
                    </Text>
                  </View>
                  {item.isClosed && (
                    <View style={[styles.typePill, { backgroundColor: '#332010', borderRadius: 6 }]}>
                      <Text style={[styles.typePillText, { color: '#E67E22' }]}>Encerrado</Text>
                    </View>
                  )}
                </View>
                {!item.isClosed && (
                  <TouchableOpacity
                    style={[styles.closeBtn, { backgroundColor: '#332010', borderRadius: 7 }]}
                    onPress={() => handleCloseDebate(item.id, item.title)}
                  >
                    <Feather name="lock" size={13} color="#E67E22" />
                  </TouchableOpacity>
                )}
              </View>
              <Text style={[styles.debateTitle, { color: colors.foreground }]} numberOfLines={2}>{item.title}</Text>
              <View style={styles.debateStats}>
                <View style={styles.statItem}>
                  <Feather name="users" size={12} color={colors.mutedForeground} />
                  <Text style={[styles.statText, { color: colors.mutedForeground }]}>{item.membersCount}</Text>
                </View>
                <View style={styles.statItem}>
                  <Feather name="message-circle" size={12} color={colors.mutedForeground} />
                  <Text style={[styles.statText, { color: colors.mutedForeground }]}>{item.repliesCount}</Text>
                </View>
                <Text style={[styles.creatorText, { color: colors.mutedForeground }]}>por {item.creatorName}</Text>
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, gap: 12 },
  title: { flex: 1, fontSize: 18, fontFamily: 'Inter_700Bold' },
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 12 },
  badgeText: { color: '#fff', fontSize: 11, fontFamily: 'Inter_700Bold' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1 },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 12 },
  tabText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  list: { padding: 20, gap: 10 },
  card: { borderWidth: 1, padding: 14 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  avatar: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#fff', fontSize: 14, fontFamily: 'Inter_700Bold' },
  cardInfo: { flex: 1 },
  cardUser: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  cardDate: { fontSize: 11, fontFamily: 'Inter_400Regular', marginTop: 2 },
  debateRef: { flexDirection: 'row', alignItems: 'center', gap: 6, padding: 10, marginBottom: 12 },
  debateRefText: { flex: 1, fontSize: 13, fontFamily: 'Inter_500Medium' },
  actions: { flexDirection: 'row', gap: 8 },
  rejectBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, borderWidth: 1, paddingVertical: 9 },
  rejectBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  approveBtn: { flex: 2, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 9 },
  approveBtnText: { color: '#fff', fontSize: 13, fontFamily: 'Inter_700Bold' },
  empty: { alignItems: 'center', paddingTop: 60, gap: 12 },
  emptyText: { fontSize: 14, fontFamily: 'Inter_500Medium', textAlign: 'center' },
  debateCard: { borderWidth: 1, padding: 14 },
  debateCardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  debateBadges: { flexDirection: 'row', gap: 6 },
  typePill: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4 },
  typePillText: { fontSize: 10, fontFamily: 'Inter_600SemiBold' },
  closeBtn: { width: 30, height: 30, alignItems: 'center', justifyContent: 'center' },
  debateTitle: { fontSize: 14, fontFamily: 'Inter_600SemiBold', lineHeight: 20, marginBottom: 8 },
  debateStats: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statText: { fontSize: 12, fontFamily: 'Inter_500Medium' },
  creatorText: { fontSize: 11, fontFamily: 'Inter_400Regular', marginLeft: 'auto' },
});
