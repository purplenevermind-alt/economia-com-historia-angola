import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { RoleBadge } from '@/components/RoleBadge';
import { useAuth } from '@/context/AuthContext';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

export default function AdminIndexScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { contents, debates, quizzes, jindungoRequests, membershipRequests } = useAppData();

  const pendingJindungo = jindungoRequests.filter(r => r.status === 'pendente').length;
  const pendingMembership = membershipRequests.filter(r => r.status === 'pendente').length;
  const totalPending = pendingJindungo + pendingMembership;

  const STATS = [
    { label: 'Conteúdos', value: contents.length, icon: 'book-open', color: colors.secondary },
    { label: 'Quizzes', value: quizzes.length, icon: 'help-circle', color: '#9B59B6' },
    { label: 'Debates', value: debates.length, icon: 'message-square', color: '#E67E22' },
    { label: 'Pendentes', value: totalPending, icon: 'clock', color: totalPending > 0 ? colors.primary : colors.success },
  ];

  const MENU = [
    { label: 'Gestão de Utilizadores', sub: 'Ver, promover e remover utilizadores', icon: 'users', route: '/admin/utilizadores', badge: null },
    { label: 'Gestão de Conteúdos', sub: 'Publicar, editar e arquivar conteúdos', icon: 'book-open', route: '/admin/conteudos', badge: null },
    { label: 'Jindungo — Acesso Premium', sub: `${pendingJindungo} solicitações pendentes`, icon: 'star', route: '/admin/jindungo', badge: pendingJindungo },
    { label: 'Moderação de Fóruns', sub: `${pendingMembership} pedidos de entrada pendentes`, icon: 'message-square', route: '/admin/foruns', badge: pendingMembership },
    { label: 'Registos de Atividade', sub: 'Logs de ações administrativas', icon: 'activity', route: '/admin/logs', badge: null },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>Painel Admin</Text>
          {user && <RoleBadge role={user.role} />}
        </View>
        <View style={{ width: 22 }} />
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 40 }} showsVerticalScrollIndicator={false}>
        {/* Welcome */}
        <View style={[styles.welcomeCard, { backgroundColor: colors.primary, marginHorizontal: 20, marginTop: 20, borderRadius: colors.radius + 4 }]}>
          <MaterialCommunityIcons name="shield-crown" size={36} color="rgba(255,255,255,0.8)" />
          <View>
            <Text style={styles.welcomeTitle}>Bem-vindo, {user?.name.split(' ')[0]}</Text>
            <Text style={styles.welcomeSub}>Painel de Administração da Plataforma</Text>
          </View>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          {STATS.map((stat, idx) => (
            <View key={idx} style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
              <View style={[styles.statIconWrap, { backgroundColor: `${stat.color}22`, borderRadius: 10 }]}>
                <Feather name={stat.icon as any} size={18} color={stat.color} />
              </View>
              <Text style={[styles.statValue, { color: colors.foreground }]}>{stat.value}</Text>
              <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{stat.label}</Text>
            </View>
          ))}
        </View>

        {/* Menu */}
        <View style={styles.menuSection}>
          <Text style={[styles.menuSectionTitle, { color: colors.mutedForeground }]}>Gestão</Text>
          <View style={[styles.menuCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
            {MENU.map((item, idx) => (
              <TouchableOpacity
                key={idx}
                style={[styles.menuItem, idx < MENU.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}
                onPress={() => router.push(item.route as any)}
                activeOpacity={0.7}
              >
                <View style={[styles.menuIconWrap, { backgroundColor: colors.muted, borderRadius: 8 }]}>
                  <Feather name={item.icon as any} size={16} color={colors.mutedForeground} />
                </View>
                <View style={styles.menuLabels}>
                  <Text style={[styles.menuLabel, { color: colors.foreground }]}>{item.label}</Text>
                  <Text style={[styles.menuSub, { color: colors.mutedForeground }]}>{item.sub}</Text>
                </View>
                {item.badge != null && item.badge > 0 && (
                  <View style={[styles.badge, { backgroundColor: colors.primary }]}>
                    <Text style={styles.badgeText}>{item.badge}</Text>
                  </View>
                )}
                <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, gap: 12 },
  headerCenter: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 },
  headerTitle: { fontSize: 20, fontFamily: 'Inter_700Bold' },
  welcomeCard: { flexDirection: 'row', alignItems: 'center', gap: 14, padding: 20 },
  welcomeTitle: { color: '#fff', fontSize: 18, fontFamily: 'Inter_700Bold' },
  welcomeSub: { color: 'rgba(255,255,255,0.7)', fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, padding: 20 },
  statCard: { width: '47%', padding: 16, borderWidth: 1, gap: 8 },
  statIconWrap: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  statValue: { fontSize: 24, fontFamily: 'Inter_700Bold' },
  statLabel: { fontSize: 12, fontFamily: 'Inter_500Medium' },
  menuSection: { paddingHorizontal: 20 },
  menuSectionTitle: { fontSize: 11, fontFamily: 'Inter_700Bold', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 10 },
  menuCard: { borderWidth: 1 },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  menuIconWrap: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center' },
  menuLabels: { flex: 1 },
  menuLabel: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  menuSub: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  badge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12, marginRight: 4 },
  badgeText: { color: '#fff', fontSize: 11, fontFamily: 'Inter_700Bold' },
});
