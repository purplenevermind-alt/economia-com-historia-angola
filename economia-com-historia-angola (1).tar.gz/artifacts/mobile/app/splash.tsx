import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import React, { useEffect, useRef } from 'react';
import { Animated, Image, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function SplashScreen() {
  const insets = useSafeAreaInsets();
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const logoScale = useRef(new Animated.Value(0.8)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;
  const lineWidth = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.timing(logoOpacity, { toValue: 1, duration: 800, useNativeDriver: true }),
        Animated.spring(logoScale, { toValue: 1, tension: 60, friction: 8, useNativeDriver: true }),
      ]),
      Animated.timing(lineWidth, { toValue: 120, duration: 500, useNativeDriver: false }),
      Animated.timing(textOpacity, { toValue: 1, duration: 600, useNativeDriver: true }),
    ]).start(() => {
      setTimeout(() => router.replace('/(auth)/login'), 1200);
    });
  }, []);

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#14161D', '#1B1E27', '#14161D']}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />
      <View style={[styles.bgPattern, { top: insets.top + 40 }]}>
        {[...Array(8)].map((_, i) => (
          <View
            key={i}
            style={[styles.bgLine, {
              top: i * 80,
              opacity: 0.04 + i * 0.005,
              transform: [{ rotate: '-15deg' }],
            }]}
          />
        ))}
      </View>
      <View style={[styles.corner, styles.cornerTL, { top: insets.top + 20 }]} />
      <View style={[styles.corner, styles.cornerBR, { bottom: insets.bottom + 20 }]} />

      <View style={styles.content}>
        <Animated.View style={{ opacity: logoOpacity, transform: [{ scale: logoScale }] }}>
          <Image
            source={require('@/assets/images/icon.png')}
            style={styles.logo}
            resizeMode="contain"
          />
        </Animated.View>

        <Animated.View style={{ width: lineWidth, height: 2, backgroundColor: '#A30D3F', marginVertical: 20 }} />

        <Animated.View style={{ opacity: textOpacity, alignItems: 'center' }}>
          <Text style={styles.appName}>Economia com História</Text>
          <Text style={styles.country}>Angola</Text>
          <Text style={styles.tagline}>Aprenda. Debata. Evolua.</Text>
        </Animated.View>
      </View>

      <Animated.View style={[styles.footer, { opacity: textOpacity, paddingBottom: insets.bottom + 20 }]}>
        <View style={styles.dot} />
        <View style={[styles.dot, styles.dotActive]} />
        <View style={styles.dot} />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#14161D' },
  bgPattern: { position: 'absolute', left: -50, right: -50, bottom: 0, overflow: 'hidden' },
  bgLine: { position: 'absolute', left: 0, right: 0, height: 1, backgroundColor: '#A30D3F' },
  corner: { position: 'absolute', width: 60, height: 60, borderColor: '#A30D3F' },
  cornerTL: { left: 24, borderTopWidth: 2, borderLeftWidth: 2 },
  cornerBR: { right: 24, borderBottomWidth: 2, borderRightWidth: 2 },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 40 },
  logo: { width: 120, height: 120, borderRadius: 28 },
  appName: { color: '#FFFFFF', fontSize: 26, fontFamily: 'Inter_700Bold', textAlign: 'center', letterSpacing: 0.5 },
  country: { color: '#A30D3F', fontSize: 18, fontFamily: 'Inter_600SemiBold', textAlign: 'center', marginTop: 4 },
  tagline: { color: '#8A8A9A', fontSize: 13, fontFamily: 'Inter_400Regular', textAlign: 'center', marginTop: 16, letterSpacing: 1 },
  footer: { alignItems: 'center', flexDirection: 'row', justifyContent: 'center', gap: 8 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#2A2D3A' },
  dotActive: { backgroundColor: '#A30D3F', width: 20 },
});
