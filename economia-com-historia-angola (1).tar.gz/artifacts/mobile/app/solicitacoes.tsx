import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '@/context/AuthContext';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

export default function SolicitacoesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { jindungoRequests, membershipRequests } = useAppData();

  const myJindungo = jindungoRequests.filter(r => r.userId === user?.id);
  const myMembership = membershipRequests.filter(r => r.userId === user?.id);

  const all = [
    ...myJindungo.map(r => ({ ...r, kind: 'jindungo' as const })),
    ...myMembership.map(r => ({ ...r, kind: 'membership' as const })),
  ].sort((a, b) => new Date(b.requestedAt).getTime() - new Date(a.requestedAt).getTime());

  function statusColor(status: string) {
    if (status === 'aprovada') return '#2ECC71';
    if (status === 'rejeitada') return colors.destructive;
    return '#E67E22';
  }

  function statusLabel(status: string) {
    if (status === 'aprovada') return 'Aprovado';
    if (status === 'rejeitada') return 'Rejeitado';
    return 'Pendente';
  }

  function statusIcon(status: string) {
    if (status === 'aprovada') return 'check-circle';
    if (status === 'rejeitada') return 'x-circle';
    return 'clock';
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>As Minhas Solicitações</Text>
        <View style={{ width: 22 }} />
      </View>

      <FlatList
        data={all}
        keyExtractor={(item, idx) => `${item.kind}-${item.id}-${idx}`}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 40 }]}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
            <View style={styles.cardTop}>
              <View style={[styles.kindBadge, { backgroundColor: item.kind === 'jindungo' ? `${colors.primary}22` : `${colors.secondary}22`, borderRadius: 6 }]}>
                <Feather name={item.kind === 'jindungo' ? 'star' : 'message-square'} size={12} color={item.kind === 'jindungo' ? colors.primary : colors.secondary} />
                <Text style={[styles.kindText, { color: item.kind === 'jindungo' ? colors.primary : colors.secondary }]}>
                  {item.kind === 'jindungo' ? 'Conteúdo Jindungo' : 'Membro Fórum'}
                </Text>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: `${statusColor(item.status)}22`, borderRadius: 6 }]}>
                <Feather name={statusIcon(item.status) as any} size={12} color={statusColor(item.status)} />
                <Text style={[styles.statusText, { color: statusColor(item.status) }]}>{statusLabel(item.status)}</Text>
              </View>
            </View>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>
              {item.kind === 'jindungo' ? (item as any).contentTitle : (item as any).debateTitle}
            </Text>
            <Text style={[styles.cardDate, { color: colors.mutedForeground }]}>
              Solicitado em {new Date(item.requestedAt).toLocaleDateString('pt-AO', { day: 'numeric', month: 'long', year: 'numeric' })}
            </Text>
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="file-text" size={48} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Sem solicitações</Text>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>As suas solicitações de acesso a conteúdos e fóruns aparecerão aqui.</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1 },
  title: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  list: { padding: 20 },
  card: { borderWidth: 1, padding: 16, marginBottom: 12 },
  cardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  kindBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 8, paddingVertical: 4 },
  kindText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  statusBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 8, paddingVertical: 4 },
  statusText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  cardTitle: { fontSize: 15, fontFamily: 'Inter_600SemiBold', marginBottom: 6 },
  cardDate: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  empty: { alignItems: 'center', paddingTop: 80, paddingHorizontal: 40, gap: 12 },
  emptyTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', marginTop: 8 },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 20 },
});
