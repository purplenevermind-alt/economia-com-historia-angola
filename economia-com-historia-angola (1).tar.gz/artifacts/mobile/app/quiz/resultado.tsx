import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useRef } from 'react';
import { Animated, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

export default function QuizResultadoScreen() {
  const params = useLocalSearchParams<{ quizId: string; score: string; total: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { quizzes } = useAppData();
  const score = parseInt(params.score ?? '0');
  const total = parseInt(params.total ?? '1');
  const percentage = Math.round((score / total) * 100);
  const quiz = quizzes.find(q => q.id === params.quizId);

  const scaleAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Haptics.notificationAsync(percentage >= 70 ? Haptics.NotificationFeedbackType.Success : Haptics.NotificationFeedbackType.Warning);
    Animated.sequence([
      Animated.spring(scaleAnim, { toValue: 1, tension: 60, friction: 7, useNativeDriver: true }),
      Animated.timing(opacityAnim, { toValue: 1, duration: 400, useNativeDriver: true }),
      Animated.timing(progressAnim, { toValue: percentage, duration: 1000, useNativeDriver: false }),
    ]).start();
  }, []);

  const medal = percentage >= 90 ? { icon: 'trophy', color: colors.gold, label: 'Ouro', bg: `${colors.gold}22` }
    : percentage >= 70 ? { icon: 'medal', color: '#C0C0C0', label: 'Prata', bg: '#C0C0C022' }
    : percentage >= 50 ? { icon: 'medal', color: '#CD7F32', label: 'Bronze', bg: '#CD7F3222' }
    : { icon: 'refresh-cw', color: colors.primary, label: 'Tentar Novamente', bg: `${colors.primary}22` };

  const feedbackText = percentage >= 90 ? 'Excelente! Domina perfeitamente este tema!'
    : percentage >= 70 ? 'Muito bom! Tem um sólido conhecimento desta matéria.'
    : percentage >= 50 ? 'Bom esforço! Continue a estudar para melhorar.'
    : 'Não desanime! A aprendizagem é um processo contínuo.';

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient colors={['#1B0A14', '#14161D']} style={StyleSheet.absoluteFill} />

      <View style={[styles.header, { paddingTop: insets.top + 16 }]}>
        <TouchableOpacity style={[styles.closeBtn, { backgroundColor: colors.muted, borderRadius: 20 }]} onPress={() => router.replace('/(tabs)/quiz')}>
          <Feather name="x" size={20} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Resultado do Quiz</Text>
        <View style={{ width: 40 }} />
      </View>

      <View style={styles.body}>
        {/* Medal */}
        <Animated.View style={[styles.medalWrap, { transform: [{ scale: scaleAnim }] }]}>
          <View style={[styles.medalBg, { backgroundColor: medal.bg, borderRadius: 60 }]}>
            <MaterialCommunityIcons name={medal.icon as any} size={64} color={medal.color} />
          </View>
          <Text style={[styles.medalLabel, { color: medal.color }]}>{medal.label}</Text>
        </Animated.View>

        {/* Score */}
        <Animated.View style={[styles.scoreSection, { opacity: opacityAnim }]}>
          <Text style={[styles.scoreNumber, { color: colors.foreground }]}>{percentage}<Text style={[styles.scorePct, { color: colors.mutedForeground }]}>%</Text></Text>
          <Text style={[styles.scoreLabel, { color: colors.mutedForeground }]}>{score} de {total} respostas corretas</Text>

          {/* Progress Circle (fake with bar) */}
          <View style={[styles.progressTrack, { backgroundColor: colors.muted, borderRadius: 4 }]}>
            <Animated.View style={[styles.progressFill, {
              width: progressAnim.interpolate({ inputRange: [0, 100], outputRange: ['0%', '100%'] }),
              backgroundColor: percentage >= 70 ? colors.success : colors.primary,
              borderRadius: 4,
            }]} />
          </View>

          {/* Feedback */}
          <View style={[styles.feedbackBox, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
            <Text style={[styles.feedbackText, { color: colors.foreground }]}>{feedbackText}</Text>
          </View>

          {quiz && (
            <Text style={[styles.quizName, { color: colors.mutedForeground }]}>{quiz.title}</Text>
          )}
        </Animated.View>
      </View>

      {/* Actions */}
      <View style={[styles.actions, { paddingBottom: insets.bottom + 20 }]}>
        {quiz && (
          <TouchableOpacity
            style={[styles.retryBtn, { borderColor: colors.border, borderRadius: colors.radius }]}
            onPress={() => router.replace(`/quiz/${quiz.id}` as any)}
            activeOpacity={0.8}
          >
            <Feather name="refresh-cw" size={16} color={colors.foreground} />
            <Text style={[styles.retryBtnText, { color: colors.foreground }]}>Refazer Quiz</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          style={[styles.homeBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
          onPress={() => router.replace('/(tabs)/quiz')}
          activeOpacity={0.8}
        >
          <Text style={styles.homeBtnText}>Ver Todos os Quizzes</Text>
          <Feather name="arrow-right" size={16} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 20 },
  closeBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: 17, fontFamily: 'Inter_700Bold' },
  body: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32 },
  medalWrap: { alignItems: 'center', marginBottom: 32 },
  medalBg: { width: 120, height: 120, alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  medalLabel: { fontSize: 16, fontFamily: 'Inter_700Bold', textTransform: 'uppercase', letterSpacing: 1 },
  scoreSection: { width: '100%', alignItems: 'center' },
  scoreNumber: { fontSize: 72, fontFamily: 'Inter_700Bold', lineHeight: 80 },
  scorePct: { fontSize: 36, fontFamily: 'Inter_600SemiBold' },
  scoreLabel: { fontSize: 15, fontFamily: 'Inter_500Medium', marginBottom: 20 },
  progressTrack: { width: '100%', height: 8, marginBottom: 20 },
  progressFill: { height: 8 },
  feedbackBox: { borderWidth: 1, padding: 16, width: '100%', marginBottom: 12 },
  feedbackText: { fontSize: 15, fontFamily: 'Inter_500Medium', textAlign: 'center', lineHeight: 22 },
  quizName: { fontSize: 12, fontFamily: 'Inter_400Regular', textAlign: 'center' },
  actions: { padding: 20, gap: 12 },
  retryBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderWidth: 1, paddingVertical: 13 },
  retryBtnText: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  homeBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 15 },
  homeBtnText: { color: '#fff', fontSize: 15, fontFamily: 'Inter_700Bold' },
});
