import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { Animated, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppData } from '@/context/AppDataContext';
import { useAuth } from '@/context/AuthContext';
import { useColors } from '@/hooks/useColors';

export default function QuizResolverScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { quizzes, saveQuizResult } = useAppData();
  const { user } = useAuth();
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [answers, setAnswers] = useState<(number | null)[]>([]);

  const quiz = quizzes.find(q => q.id === id);
  if (!quiz) {
    return (
      <View style={[styles.notFound, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.foreground }}>Quiz não encontrado</Text>
      </View>
    );
  }

  const question = quiz.questions[current];
  const progress = (current / quiz.questions.length) * 100;
  const isLast = current === quiz.questions.length - 1;

  function handleSelect(optionIdx: number) {
    if (confirmed) return;
    setSelected(optionIdx);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }

  function handleConfirm() {
    if (selected === null) return;
    setConfirmed(true);
    if (selected === question.correctAnswer) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } else {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  }

  function handleNext() {
    const newAnswers = [...answers, selected];
    if (isLast) {
      const score = newAnswers.filter((ans, idx) => ans === quiz.questions[idx].correctAnswer).length;
      if (user) {
        saveQuizResult({ quizId: quiz.id, score, total: quiz.questions.length, completedAt: new Date().toISOString() });
      }
      router.replace({ pathname: '/quiz/resultado', params: { quizId: quiz.id, score: String(score), total: String(quiz.questions.length) } });
    } else {
      setAnswers(newAnswers);
      setCurrent(c => c + 1);
      setSelected(null);
      setConfirmed(false);
    }
  }

  function getOptionStyle(idx: number) {
    if (!confirmed) {
      return {
        backgroundColor: selected === idx ? `${colors.primary}22` : colors.card,
        borderColor: selected === idx ? colors.primary : colors.border,
      };
    }
    if (idx === question.correctAnswer) return { backgroundColor: '#1A3A20', borderColor: '#2ECC71' };
    if (idx === selected && selected !== question.correctAnswer) return { backgroundColor: '#3A1A1A', borderColor: colors.destructive };
    return { backgroundColor: colors.card, borderColor: colors.border };
  }

  function getOptionTextColor(idx: number) {
    if (!confirmed) return selected === idx ? colors.primary : colors.foreground;
    if (idx === question.correctAnswer) return '#2ECC71';
    if (idx === selected && selected !== question.correctAnswer) return colors.destructive;
    return colors.mutedForeground;
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <TouchableOpacity onPress={() => router.back()}>
          <Feather name="x" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={[styles.quizTitle, { color: colors.mutedForeground }]} numberOfLines={1}>{quiz.title}</Text>
          <Text style={[styles.questionCount, { color: colors.foreground }]}>{current + 1} / {quiz.questions.length}</Text>
        </View>
        <View style={{ width: 22 }} />
      </View>

      {/* Progress Bar */}
      <View style={[styles.progressTrack, { backgroundColor: colors.muted }]}>
        <View style={[styles.progressFill, { width: `${progress}%`, backgroundColor: colors.primary }]} />
      </View>

      <View style={styles.body}>
        {/* Question */}
        <View style={[styles.questionCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius + 4 }]}>
          <View style={[styles.qNumBadge, { backgroundColor: `${colors.primary}22`, borderRadius: 20 }]}>
            <Text style={[styles.qNumText, { color: colors.primary }]}>Pergunta {current + 1}</Text>
          </View>
          <Text style={[styles.questionText, { color: colors.foreground }]}>{question.question}</Text>
        </View>

        {/* Options */}
        <View style={styles.options}>
          {question.options.map((option, idx) => (
            <TouchableOpacity
              key={idx}
              style={[styles.optionBtn, getOptionStyle(idx), { borderRadius: colors.radius }]}
              onPress={() => handleSelect(idx)}
              activeOpacity={0.8}
            >
              <View style={[styles.optionLetter, { backgroundColor: confirmed && idx === question.correctAnswer ? '#2ECC71' : confirmed && idx === selected && selected !== question.correctAnswer ? colors.destructive : selected === idx ? colors.primary : colors.muted, borderRadius: 16 }]}>
                <Text style={[styles.optionLetterText, { color: confirmed || selected === idx ? '#fff' : colors.mutedForeground }]}>
                  {String.fromCharCode(65 + idx)}
                </Text>
              </View>
              <Text style={[styles.optionText, { color: getOptionTextColor(idx) }]}>{option}</Text>
              {confirmed && idx === question.correctAnswer && <Feather name="check" size={18} color="#2ECC71" />}
              {confirmed && idx === selected && selected !== question.correctAnswer && <Feather name="x" size={18} color={colors.destructive} />}
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Bottom Action */}
      <View style={[styles.bottomBar, { borderTopColor: colors.border, paddingBottom: insets.bottom + 12 }]}>
        {!confirmed ? (
          <TouchableOpacity
            style={[styles.confirmBtn, { backgroundColor: selected !== null ? colors.primary : colors.muted, borderRadius: colors.radius }]}
            onPress={handleConfirm}
            disabled={selected === null}
          >
            <Text style={[styles.confirmBtnText, { color: selected !== null ? '#fff' : colors.mutedForeground }]}>Confirmar Resposta</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={[styles.confirmBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
            onPress={handleNext}
          >
            <Text style={styles.confirmBtnText}>{isLast ? 'Ver Resultado' : 'Próxima Pergunta'}</Text>
            <Feather name={isLast ? 'award' : 'arrow-right'} size={18} color="#fff" />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  notFound: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  header: { flexDirection: 'row', alignItems: 'flex-start', paddingHorizontal: 20, paddingBottom: 12, gap: 12 },
  headerCenter: { flex: 1, alignItems: 'center' },
  quizTitle: { fontSize: 11, fontFamily: 'Inter_500Medium', textTransform: 'uppercase', letterSpacing: 0.5 },
  questionCount: { fontSize: 16, fontFamily: 'Inter_700Bold', marginTop: 2 },
  progressTrack: { height: 4, marginHorizontal: 20, borderRadius: 2, marginBottom: 20 },
  progressFill: { height: 4, borderRadius: 2 },
  body: { flex: 1, paddingHorizontal: 20 },
  questionCard: { borderWidth: 1, padding: 20, marginBottom: 20 },
  qNumBadge: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, marginBottom: 12 },
  qNumText: { fontSize: 11, fontFamily: 'Inter_700Bold', textTransform: 'uppercase', letterSpacing: 0.5 },
  questionText: { fontSize: 18, fontFamily: 'Inter_700Bold', lineHeight: 26 },
  options: { gap: 10 },
  optionBtn: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14, borderWidth: 1 },
  optionLetter: { width: 32, height: 32, alignItems: 'center', justifyContent: 'center' },
  optionLetterText: { fontSize: 13, fontFamily: 'Inter_700Bold' },
  optionText: { flex: 1, fontSize: 15, fontFamily: 'Inter_500Medium', lineHeight: 21 },
  bottomBar: { padding: 20, borderTopWidth: 1 },
  confirmBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 15 },
  confirmBtnText: { color: '#fff', fontSize: 16, fontFamily: 'Inter_700Bold' },
});
