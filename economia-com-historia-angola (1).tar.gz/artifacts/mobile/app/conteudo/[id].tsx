import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { Alert, ScrollView, Share, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { JindungoModal } from '@/components/JindungoModal';
import { RoleBadge } from '@/components/RoleBadge';
import { useAuth } from '@/context/AuthContext';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

const IMAGES: Record<string, any> = {
  historia: require('@/assets/images/content_historia.png'),
  economia: require('@/assets/images/content_economia.png'),
};

export default function ConteudoDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { contents, toggleFavorite, isFavorite, requestJindungoAccess, hasJindungoAccess, hasPendingRequest, isAdmin } = useAppData();
  const [showJindungo, setShowJindungo] = useState(false);

  const content = contents.find(c => c.id === id);
  if (!content) {
    return (
      <View style={[styles.notFound, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.foreground }}>Conteúdo não encontrado</Text>
      </View>
    );
  }

  const canRead = content.type === 'publico' || (user && hasJindungoAccess(content.id, user.id)) || isAdmin;
  const pending = user ? hasPendingRequest(content.id, user.id) : false;
  const favorite = isFavorite(content.id);

  function handleFavorite() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    toggleFavorite(content.id);
  }

  async function handleShare() {
    try {
      await Share.share({ message: `${content.title} - Economia com História Angola\n\n${content.summary}` });
    } catch { }
  }

  function handleReadFull() {
    if (!canRead) {
      setShowJindungo(true);
    }
  }

  function handleJindungoRequest() {
    if (!user) return;
    requestJindungoAccess(content.id, user.id, user.name);
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}>
        {/* Hero Image */}
        <View style={styles.imageWrap}>
          <Image source={IMAGES[content.imageKey] ?? IMAGES.historia} style={styles.heroImage} contentFit="cover" />
          <LinearGradient colors={['rgba(20,22,29,0.7)', '#14161D']} style={[StyleSheet.absoluteFill, { justifyContent: 'flex-end' }]} />
          <TouchableOpacity style={[styles.backBtn, { top: insets.top + 12, backgroundColor: 'rgba(0,0,0,0.5)', borderRadius: 20 }]} onPress={() => router.back()}>
            <Feather name="arrow-left" size={20} color="#fff" />
          </TouchableOpacity>
          <View style={styles.imageOverlay}>
            <View style={styles.metaRow}>
              <View style={[styles.catBadge, { backgroundColor: content.category === 'Historia' ? '#1E3A5F' : '#2D1B33', borderRadius: 6 }]}>
                <Text style={[styles.catText, { color: content.category === 'Historia' ? '#5B9BD5' : '#B86CC8' }]}>
                  {content.category === 'Historia' ? 'História' : 'Economia'}
                </Text>
              </View>
              {content.type === 'jindungo' && (
                <View style={[styles.jindungoBadge, { backgroundColor: colors.primary, borderRadius: 6 }]}>
                  <MaterialCommunityIcons name="star-four-points" size={10} color="#fff" />
                  <Text style={styles.jindungoText}>Jindungo</Text>
                </View>
              )}
            </View>
          </View>
        </View>

        <View style={styles.body}>
          <Text style={[styles.title, { color: colors.foreground }]}>{content.title}</Text>

          <View style={styles.authorRow}>
            <View style={[styles.authorAvatar, { backgroundColor: colors.primary, borderRadius: 18 }]}>
              <Text style={styles.authorAvatarText}>{content.author.charAt(0)}</Text>
            </View>
            <View>
              <Text style={[styles.authorName, { color: colors.foreground }]}>{content.author}</Text>
              <Text style={[styles.authorDate, { color: colors.mutedForeground }]}>{new Date(content.date).toLocaleDateString('pt-AO', { day: 'numeric', month: 'long', year: 'numeric' })}</Text>
            </View>
            <View style={styles.viewsWrap}>
              <Feather name="eye" size={13} color={colors.mutedForeground} />
              <Text style={[styles.viewsText, { color: colors.mutedForeground }]}>{content.views.toLocaleString()}</Text>
            </View>
          </View>

          {/* Action Bar */}
          <View style={[styles.actionBar, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
            <TouchableOpacity style={styles.actionBtn} onPress={handleFavorite}>
              <Feather name={favorite ? 'heart' : 'heart'} size={18} color={favorite ? colors.primary : colors.mutedForeground} />
              <Text style={[styles.actionLabel, { color: favorite ? colors.primary : colors.mutedForeground }]}>Favoritar</Text>
            </TouchableOpacity>
            <View style={[styles.actionDivider, { backgroundColor: colors.border }]} />
            <TouchableOpacity style={styles.actionBtn} onPress={handleShare}>
              <Feather name="share-2" size={18} color={colors.secondary} />
              <Text style={[styles.actionLabel, { color: colors.secondary }]}>Partilhar</Text>
            </TouchableOpacity>
            <View style={[styles.actionDivider, { backgroundColor: colors.border }]} />
            <TouchableOpacity style={styles.actionBtn} onPress={() => Alert.alert('Comentários', 'Funcionalidade em breve.')}>
              <Feather name="message-circle" size={18} color={colors.mutedForeground} />
              <Text style={[styles.actionLabel, { color: colors.mutedForeground }]}>Comentar</Text>
            </TouchableOpacity>
          </View>

          {/* Summary */}
          <View style={[styles.summaryBox, { backgroundColor: `${colors.primary}12`, borderColor: `${colors.primary}30`, borderRadius: colors.radius }]}>
            <Text style={[styles.summaryLabel, { color: colors.primary }]}>Resumo</Text>
            <Text style={[styles.summaryText, { color: colors.foreground }]}>{content.summary}</Text>
          </View>

          {/* Content Body */}
          {canRead ? (
            <View>
              <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>Conteúdo Completo</Text>
              <Text style={[styles.bodyText, { color: colors.foreground }]}>{content.body}</Text>
            </View>
          ) : (
            <View style={[styles.lockedBox, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
              <View style={[styles.lockIconWrap, { backgroundColor: `${colors.primary}22`, borderRadius: 30 }]}>
                <MaterialCommunityIcons name="star-four-points" size={28} color={colors.primary} />
              </View>
              <Text style={[styles.lockedTitle, { color: colors.foreground }]}>Conteúdo Jindungo</Text>
              <Text style={[styles.lockedText, { color: colors.mutedForeground }]}>
                Este conteúdo requer autorização especial para ser lido na íntegra.
              </Text>
              {pending ? (
                <View style={[styles.pendingBox, { backgroundColor: '#1A3A20', borderRadius: colors.radius }]}>
                  <Feather name="clock" size={16} color="#2ECC71" />
                  <Text style={styles.pendingText}>Solicitação pendente de aprovação</Text>
                </View>
              ) : (
                <TouchableOpacity
                  style={[styles.requestBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
                  onPress={() => setShowJindungo(true)}
                  activeOpacity={0.8}
                >
                  <Text style={styles.requestBtnText}>Ler Conteúdo Completo</Text>
                  <Feather name="arrow-right" size={16} color="#fff" />
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>
      </ScrollView>

      <JindungoModal
        visible={showJindungo}
        contentTitle={content.title}
        hasPending={pending}
        onRequest={handleJindungoRequest}
        onClose={() => setShowJindungo(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  notFound: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  imageWrap: { height: 280, position: 'relative' },
  heroImage: { width: '100%', height: 280 },
  backBtn: { position: 'absolute', left: 16, width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  imageOverlay: { position: 'absolute', bottom: 16, left: 16, right: 16 },
  metaRow: { flexDirection: 'row', gap: 8 },
  catBadge: { paddingHorizontal: 10, paddingVertical: 4 },
  catText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  jindungoBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 4 },
  jindungoText: { fontSize: 12, fontFamily: 'Inter_600SemiBold', color: '#fff' },
  body: { padding: 20 },
  title: { fontSize: 22, fontFamily: 'Inter_700Bold', lineHeight: 30, marginBottom: 16 },
  authorRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 16 },
  authorAvatar: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  authorAvatarText: { color: '#fff', fontSize: 14, fontFamily: 'Inter_700Bold' },
  authorName: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  authorDate: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  viewsWrap: { marginLeft: 'auto', flexDirection: 'row', alignItems: 'center', gap: 4 },
  viewsText: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  actionBar: { flexDirection: 'row', borderWidth: 1, marginBottom: 20 },
  actionBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12 },
  actionLabel: { fontSize: 12, fontFamily: 'Inter_500Medium' },
  actionDivider: { width: 1 },
  summaryBox: { borderWidth: 1, padding: 14, marginBottom: 20 },
  summaryLabel: { fontSize: 11, fontFamily: 'Inter_700Bold', letterSpacing: 1, marginBottom: 6, textTransform: 'uppercase' },
  summaryText: { fontSize: 14, fontFamily: 'Inter_400Regular', lineHeight: 21 },
  sectionLabel: { fontSize: 11, fontFamily: 'Inter_600SemiBold', letterSpacing: 1, marginBottom: 12, textTransform: 'uppercase' },
  bodyText: { fontSize: 15, fontFamily: 'Inter_400Regular', lineHeight: 24 },
  lockedBox: { borderWidth: 1, padding: 24, alignItems: 'center' },
  lockIconWrap: { width: 60, height: 60, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  lockedTitle: { fontSize: 18, fontFamily: 'Inter_700Bold', marginBottom: 8 },
  lockedText: { fontSize: 14, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 20, marginBottom: 20 },
  pendingBox: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, width: '100%' },
  pendingText: { color: '#2ECC71', fontFamily: 'Inter_500Medium', fontSize: 13 },
  requestBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 13, paddingHorizontal: 20 },
  requestBtnText: { color: '#fff', fontSize: 15, fontFamily: 'Inter_700Bold' },
});
