import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import React from 'react';
import { Alert, Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { RoleBadge } from '@/components/RoleBadge';
import { useAuth } from '@/context/AuthContext';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

export default function PerfilScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, logout, isAdmin } = useAuth();
  const { quizResults, debates } = useAppData();
  const topPad = Platform.OS === 'web' ? 67 : insets.top;

  const userDebates = debates.filter(d => d.creatorId === user?.id).length;
  const avgScore = quizResults.length > 0
    ? Math.round(quizResults.reduce((acc, r) => acc + (r.score / r.total) * 100, 0) / quizResults.length)
    : 0;

  async function handleLogout() {
    Alert.alert('Terminar Sessão', 'Tem a certeza que deseja terminar a sessão?', [
      { text: 'Cancelar', style: 'cancel' },
      {
        text: 'Terminar', style: 'destructive', onPress: async () => {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          await logout();
          router.replace('/splash');
        }
      }
    ]);
  }

  if (!user) return null;

  const STAT_ITEMS = [
    { label: 'Quizzes', value: quizResults.length, icon: 'head-question-outline' as const, isMCI: true },
    { label: 'Debates', value: userDebates, icon: 'message-square' as const, isMCI: false },
    { label: 'Pontuação', value: user.pontuacaoTotal, icon: 'star' as const, isMCI: false },
    { label: 'Média Quiz', value: `${avgScore}%`, icon: 'percent' as const, isMCI: false },
  ];

  const MENU_ITEMS = [
    { label: 'Os meus favoritos', icon: 'heart', onPress: () => router.push('/favoritos' as any) },
    { label: 'As minhas solicitações', icon: 'file-text', onPress: () => router.push('/solicitacoes' as any) },
    { label: 'Configurações', icon: 'settings', onPress: () => router.push('/configuracoes' as any) },
    ...(isAdmin ? [{ label: 'Painel Administrativo', icon: 'shield', onPress: () => router.push('/admin' as any) }] : []),
  ];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 80 }}
      showsVerticalScrollIndicator={false}
    >
      <View style={[styles.header, { paddingTop: topPad + 20, borderBottomColor: colors.border }]}>
        <View style={[styles.avatarWrap, { backgroundColor: colors.primary, borderRadius: 40 }]}>
          <Text style={styles.avatarText}>{user.name.charAt(0).toUpperCase()}</Text>
        </View>
        <Text style={[styles.userName, { color: colors.foreground }]}>{user.name}</Text>
        <Text style={[styles.userEmail, { color: colors.mutedForeground }]}>{user.email}</Text>
        <View style={styles.badgeRow}>
          <RoleBadge role={user.role} size="md" />
          {user.role === 'super_administrador' && (
            <View style={[styles.superBadge, { backgroundColor: `${colors.gold}22`, borderColor: `${colors.gold}44`, borderRadius: 8 }]}>
              <MaterialCommunityIcons name="shield-crown" size={14} color={colors.gold} />
              <Text style={[styles.superText, { color: colors.gold }]}>Super Administrador Principal</Text>
            </View>
          )}
        </View>
        <Text style={[styles.memberSince, { color: colors.mutedForeground }]}>Membro desde {new Date(user.createdAt).toLocaleDateString('pt-AO', { month: 'long', year: 'numeric' })}</Text>
      </View>

      <View style={styles.body}>
        {/* Stats */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Estatísticas</Text>
        <View style={styles.statsGrid}>
          {STAT_ITEMS.map((item, idx) => (
            <View key={idx} style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
              {item.isMCI
                ? <MaterialCommunityIcons name={item.icon as any} size={22} color={colors.primary} />
                : <Feather name={item.icon as any} size={22} color={colors.primary} />
              }
              <Text style={[styles.statValue, { color: colors.foreground }]}>{item.value}</Text>
              <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{item.label}</Text>
            </View>
          ))}
        </View>

        {/* Menu */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Conta</Text>
        <View style={[styles.menuCard, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}>
          {MENU_ITEMS.map((item, idx) => (
            <TouchableOpacity
              key={idx}
              style={[styles.menuItem, idx < MENU_ITEMS.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }]}
              onPress={item.onPress}
              activeOpacity={0.7}
            >
              <View style={[styles.menuIcon, { backgroundColor: colors.muted, borderRadius: 8 }]}>
                <Feather name={item.icon as any} size={16} color={colors.mutedForeground} />
              </View>
              <Text style={[styles.menuLabel, { color: colors.foreground }]}>{item.label}</Text>
              <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity
          style={[styles.logoutBtn, { borderColor: colors.destructive, borderRadius: colors.radius }]}
          onPress={handleLogout}
          activeOpacity={0.8}
        >
          <Feather name="log-out" size={16} color={colors.destructive} />
          <Text style={[styles.logoutText, { color: colors.destructive }]}>Terminar Sessão</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { alignItems: 'center', paddingHorizontal: 24, paddingBottom: 24, borderBottomWidth: 1 },
  avatarWrap: { width: 80, height: 80, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  avatarText: { color: '#fff', fontSize: 32, fontFamily: 'Inter_700Bold' },
  userName: { fontSize: 22, fontFamily: 'Inter_700Bold', marginBottom: 4 },
  userEmail: { fontSize: 13, fontFamily: 'Inter_400Regular', marginBottom: 10 },
  badgeRow: { flexDirection: 'row', gap: 8, alignItems: 'center', marginBottom: 8, flexWrap: 'wrap', justifyContent: 'center' },
  superBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 4, borderWidth: 1 },
  superText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  memberSince: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  body: { padding: 20 },
  sectionTitle: { fontSize: 18, fontFamily: 'Inter_700Bold', marginBottom: 14, marginTop: 8 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 24 },
  statCard: { width: '47%', alignItems: 'center', padding: 16, borderWidth: 1, gap: 6 },
  statValue: { fontSize: 22, fontFamily: 'Inter_700Bold' },
  statLabel: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  menuCard: { borderWidth: 1, marginBottom: 20 },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  menuIcon: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center' },
  menuLabel: { flex: 1, fontSize: 15, fontFamily: 'Inter_500Medium' },
  logoutBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderWidth: 1, paddingVertical: 14, borderRadius: 12 },
  logoutText: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
});
