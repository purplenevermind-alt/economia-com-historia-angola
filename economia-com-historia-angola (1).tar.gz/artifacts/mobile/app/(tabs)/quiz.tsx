import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import React, { useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { QuizCard } from '@/components/QuizCard';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';
import { ContentCategory } from '@/types';

type Filter = 'Todos' | ContentCategory;

export default function QuizScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { quizzes, quizResults } = useAppData();
  const [filter, setFilter] = useState<Filter>('Todos');
  const topPad = Platform.OS === 'web' ? 67 : insets.top;

  const filtered = filter === 'Todos' ? quizzes : quizzes.filter(q => q.category === filter);
  const FILTERS: Filter[] = ['Todos', 'Historia', 'Economia'];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 16, borderBottomColor: colors.border }]}>
        <Text style={[styles.title, { color: colors.foreground }]}>Quizzes</Text>
        <View style={[styles.bannerWrap, { borderRadius: colors.radius, borderColor: `${colors.primary}44` }]}>
          <Image source={require('@/assets/images/quiz_banner.png')} style={StyleSheet.absoluteFill as any} contentFit="cover" />
          <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(20,22,29,0.75)', borderRadius: colors.radius }]} />
          <View style={styles.bannerContent}>
            <MaterialCommunityIcons name="head-question-outline" size={32} color={colors.primary} />
            <Text style={[styles.bannerTitle, { color: colors.foreground }]}>Teste os seus conhecimentos</Text>
            <Text style={[styles.bannerSub, { color: colors.mutedForeground }]}>{quizResults.length} de {quizzes.length} quizzes concluídos</Text>
          </View>
        </View>
        <View style={styles.filters}>
          {FILTERS.map(f => (
            <TouchableOpacity
              key={f}
              style={[styles.filterBtn, { backgroundColor: filter === f ? colors.primary : colors.muted, borderRadius: 20 }]}
              onPress={() => setFilter(f)}
            >
              <Text style={[styles.filterText, { color: filter === f ? '#fff' : colors.mutedForeground }]}>
                {f === 'Historia' ? 'História' : f}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <QuizCard quiz={item} result={quizResults.find(r => r.quizId === item.id)} />}
        contentContainerStyle={[styles.list, { paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 80 }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="head-question-outline" size={40} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Nenhum quiz disponível</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1 },
  title: { fontSize: 26, fontFamily: 'Inter_700Bold', marginBottom: 14 },
  bannerWrap: { height: 110, overflow: 'hidden', borderWidth: 1, marginBottom: 14 },
  bannerContent: { padding: 16, flexDirection: 'row', alignItems: 'center', gap: 12 },
  bannerTitle: { fontSize: 16, fontFamily: 'Inter_700Bold', flex: 1 },
  bannerSub: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  filters: { flexDirection: 'row', gap: 8 },
  filterBtn: { paddingHorizontal: 16, paddingVertical: 7 },
  filterText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  list: { padding: 20 },
  empty: { alignItems: 'center', justifyContent: 'center', paddingTop: 60, gap: 12 },
  emptyText: { fontSize: 15, fontFamily: 'Inter_500Medium' },
});
