import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import React from 'react';
import { FlatList, Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ContentCard } from '@/components/ContentCard';
import { StatCard } from '@/components/StatCard';
import { useAuth } from '@/context/AuthContext';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, isAdmin } = useAuth();
  const { contents, platformStats } = useAppData();

  const topContents = contents.filter(c => c.type === 'publico').slice(0, 3);
  const recentContents = contents.slice(0, 4);
  const topPad = Platform.OS === 'web' ? 67 : insets.top;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 80 }}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <LinearGradient colors={['#1B0A14', '#14161D']} style={[styles.headerGrad, { paddingTop: topPad + 16 }]}>
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <Image source={require('@/assets/images/icon.png')} style={styles.headerLogo} />
            <View>
              <Text style={[styles.greeting, { color: colors.mutedForeground }]}>Bem-vindo,</Text>
              <Text style={[styles.userName, { color: colors.foreground }]} numberOfLines={1}>{user?.name?.split(' ')[0] ?? 'Utilizador'}</Text>
            </View>
          </View>
          <View style={styles.headerActions}>
            {isAdmin && (
              <TouchableOpacity style={[styles.adminBtn, { backgroundColor: `${colors.gold}22`, borderColor: `${colors.gold}44`, borderRadius: 10 }]} onPress={() => router.push('/admin' as any)}>
                <MaterialCommunityIcons name="shield-crown" size={18} color={colors.gold} />
              </TouchableOpacity>
            )}
            <TouchableOpacity style={[styles.iconBtn, { backgroundColor: colors.muted, borderRadius: 10 }]} onPress={() => router.push('/favoritos' as any)}>
              <Feather name="heart" size={18} color={colors.foreground} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Hero Banner */}
        <View style={[styles.heroBanner, { borderRadius: colors.radius + 2, borderColor: `${colors.primary}44` }]}>
          <Image source={require('@/assets/images/hero_banner.png')} style={StyleSheet.absoluteFill as any} contentFit="cover" />
          <LinearGradient colors={['transparent', 'rgba(20,22,29,0.95)']} style={[StyleSheet.absoluteFill, { borderRadius: colors.radius + 2 }]} />
          <View style={styles.heroContent}>
            <View style={[styles.heroBadge, { backgroundColor: colors.primary, borderRadius: 6 }]}>
              <Text style={styles.heroBadgeText}>Plataforma Educativa</Text>
            </View>
            <Text style={[styles.heroTitle, { color: colors.foreground }]}>Aprenda História e Economia de Angola</Text>
            <View style={styles.heroBtns}>
              <TouchableOpacity style={[styles.heroBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]} onPress={() => router.push('/(tabs)/conteudos' as any)}>
                <Feather name="book-open" size={15} color="#fff" />
                <Text style={styles.heroBtnText}>Começar a Aprender</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.heroBtn, styles.heroBtnOutline, { borderColor: colors.border, borderRadius: colors.radius }]} onPress={() => router.push('/(tabs)/quiz' as any)}>
                <MaterialCommunityIcons name="head-question-outline" size={15} color={colors.foreground} />
                <Text style={[styles.heroBtnText, { color: colors.foreground }]}>Fazer Quiz</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </LinearGradient>

      <View style={styles.body}>
        {/* Stats */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Estatísticas da Plataforma</Text>
        <View style={styles.statsRow}>
          <StatCard label="Utilizadores" value={platformStats.totalUsers.toLocaleString()} icon={<Feather name="users" size={18} color={colors.primary} />} accent />
          <StatCard label="Conteúdos" value={platformStats.totalContents} icon={<Feather name="book-open" size={18} color={colors.mutedForeground} />} />
        </View>
        <View style={[styles.statsRow, { marginTop: 8 }]}>
          <StatCard label="Quizzes" value={platformStats.totalQuizzes} icon={<MaterialCommunityIcons name="head-question-outline" size={18} color={colors.mutedForeground} />} />
          <StatCard label="Debates" value={platformStats.totalDebates} icon={<Feather name="message-square" size={18} color={colors.mutedForeground} />} />
        </View>

        {/* Em Alta */}
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Em Alta Esta Semana</Text>
          <TouchableOpacity onPress={() => router.push('/(tabs)/conteudos' as any)}>
            <Text style={[styles.seeAll, { color: colors.primary }]}>Ver todos</Text>
          </TouchableOpacity>
        </View>
        {topContents.map(content => (
          <ContentCard key={content.id} content={content} compact />
        ))}

        {/* Recentes */}
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Conteúdos Recentes</Text>
          <TouchableOpacity onPress={() => router.push('/(tabs)/conteudos' as any)}>
            <Text style={[styles.seeAll, { color: colors.primary }]}>Ver todos</Text>
          </TouchableOpacity>
        </View>
        {recentContents.map(content => (
          <ContentCard key={content.id} content={content} />
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerGrad: { paddingHorizontal: 20, paddingBottom: 24 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  headerLogo: { width: 40, height: 40, borderRadius: 10 },
  greeting: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  userName: { fontSize: 18, fontFamily: 'Inter_700Bold', maxWidth: 180 },
  headerActions: { flexDirection: 'row', gap: 8 },
  adminBtn: { width: 38, height: 38, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  iconBtn: { width: 38, height: 38, alignItems: 'center', justifyContent: 'center' },
  heroBanner: { height: 220, overflow: 'hidden', borderWidth: 1 },
  heroContent: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 16 },
  heroBadge: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, marginBottom: 8 },
  heroBadgeText: { color: '#fff', fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  heroTitle: { fontSize: 18, fontFamily: 'Inter_700Bold', lineHeight: 24, marginBottom: 12 },
  heroBtns: { flexDirection: 'row', gap: 10 },
  heroBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 9 },
  heroBtnOutline: { borderWidth: 1 },
  heroBtnText: { color: '#fff', fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  body: { padding: 20 },
  statsRow: { flexDirection: 'row', gap: 10 },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  sectionTitle: { fontSize: 18, fontFamily: 'Inter_700Bold', marginBottom: 14, marginTop: 24 },
  seeAll: { fontSize: 13, fontFamily: 'Inter_500Medium', marginBottom: 14, marginTop: 24 },
});
