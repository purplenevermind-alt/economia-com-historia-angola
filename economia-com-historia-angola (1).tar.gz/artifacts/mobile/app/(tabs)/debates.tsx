import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { FlatList, Platform, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { DebateCard } from '@/components/DebateCard';
import { useAppData } from '@/context/AppDataContext';
import { useColors } from '@/hooks/useColors';

type Filter = 'Todos' | 'publico' | 'privado';

export default function DebatesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { debates } = useAppData();
  const [filter, setFilter] = useState<Filter>('Todos');
  const topPad = Platform.OS === 'web' ? 67 : insets.top;

  const filtered = filter === 'Todos' ? debates : debates.filter(d => d.type === filter);
  const FILTERS: { key: Filter; label: string }[] = [
    { key: 'Todos', label: 'Todos' },
    { key: 'publico', label: 'Públicos' },
    { key: 'privado', label: 'Privados' },
  ];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 16, borderBottomColor: colors.border }]}>
        <View style={styles.titleRow}>
          <Text style={[styles.title, { color: colors.foreground }]}>Fóruns e Debates</Text>
          <TouchableOpacity
            style={[styles.createBtn, { backgroundColor: colors.primary, borderRadius: 10 }]}
            onPress={() => router.push('/debate/criar' as any)}
          >
            <Feather name="plus" size={18} color="#fff" />
            <Text style={styles.createBtnText}>Criar</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.filters}>
          {FILTERS.map(f => (
            <TouchableOpacity
              key={f.key}
              style={[styles.filterBtn, { backgroundColor: filter === f.key ? colors.primary : colors.muted, borderRadius: 20 }]}
              onPress={() => setFilter(f.key)}
            >
              <Text style={[styles.filterText, { color: filter === f.key ? '#fff' : colors.mutedForeground }]}>{f.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        renderItem={({ item }) => <DebateCard debate={item} />}
        contentContainerStyle={[styles.list, { paddingBottom: Platform.OS === 'web' ? 34 : insets.bottom + 80 }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="message-square" size={40} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Nenhum debate encontrado</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1 },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  title: { fontSize: 26, fontFamily: 'Inter_700Bold' },
  createBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 8 },
  createBtnText: { color: '#fff', fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  filters: { flexDirection: 'row', gap: 8 },
  filterBtn: { paddingHorizontal: 16, paddingVertical: 7 },
  filterText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  list: { padding: 20 },
  empty: { alignItems: 'center', justifyContent: 'center', paddingTop: 60, gap: 12 },
  emptyText: { fontSize: 15, fontFamily: 'Inter_500Medium' },
});
