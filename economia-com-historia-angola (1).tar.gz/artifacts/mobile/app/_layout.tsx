import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import React, { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AuthProvider } from "@/context/AuthContext";
import { AppDataProvider } from "@/context/AppDataContext";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <AuthProvider>
            <AppDataProvider>
              <GestureHandlerRootView style={{ flex: 1 }}>
                <KeyboardProvider>
                  <StatusBar style="light" />
                  <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: '#14161D' } }}>
                    <Stack.Screen name="index" />
                    <Stack.Screen name="splash" />
                    <Stack.Screen name="(auth)" />
                    <Stack.Screen name="(tabs)" />
                    <Stack.Screen name="conteudo/[id]" options={{ animation: 'slide_from_right' }} />
                    <Stack.Screen name="debate/[id]" options={{ animation: 'slide_from_right' }} />
                    <Stack.Screen name="debate/criar" options={{ animation: 'slide_from_bottom' }} />
                    <Stack.Screen name="quiz/[id]" options={{ animation: 'slide_from_right' }} />
                    <Stack.Screen name="quiz/resultado" options={{ animation: 'fade' }} />
                    <Stack.Screen name="favoritos" options={{ animation: 'slide_from_right' }} />
                    <Stack.Screen name="configuracoes" options={{ animation: 'slide_from_right' }} />
                    <Stack.Screen name="solicitacoes" options={{ animation: 'slide_from_right' }} />
                    <Stack.Screen name="admin" options={{ animation: 'slide_from_right' }} />
                  </Stack>
                </KeyboardProvider>
              </GestureHandlerRootView>
            </AppDataProvider>
          </AuthProvider>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
