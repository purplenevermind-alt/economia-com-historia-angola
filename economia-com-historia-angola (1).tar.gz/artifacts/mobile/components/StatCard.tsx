import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';

interface Props {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  accent?: boolean;
}

export function StatCard({ label, value, icon, accent }: Props) {
  const colors = useColors();
  return (
    <View style={[styles.card, {
      backgroundColor: accent ? `${colors.primary}18` : colors.card,
      borderColor: accent ? `${colors.primary}44` : colors.border,
      borderRadius: colors.radius,
    }]}>
      <View style={[styles.iconWrap, { backgroundColor: accent ? `${colors.primary}22` : colors.muted, borderRadius: 10 }]}>
        {icon}
      </View>
      <Text style={[styles.value, { color: accent ? colors.primary : colors.foreground }]}>{value}</Text>
      <Text style={[styles.label, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { flex: 1, alignItems: 'center', padding: 14, borderWidth: 1, gap: 6 },
  iconWrap: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  value: { fontSize: 22, fontFamily: 'Inter_700Bold' },
  label: { fontSize: 11, fontFamily: 'Inter_500Medium', textAlign: 'center' },
});
