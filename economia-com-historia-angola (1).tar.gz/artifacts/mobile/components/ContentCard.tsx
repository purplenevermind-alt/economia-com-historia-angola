import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { router } from 'expo-router';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Content } from '@/types';

interface Props {
  content: Content;
  isFavorite?: boolean;
  compact?: boolean;
}

const IMAGES: Record<string, any> = {
  historia: require('@/assets/images/content_historia.png'),
  economia: require('@/assets/images/content_economia.png'),
};

export function ContentCard({ content, isFavorite, compact }: Props) {
  const colors = useColors();

  return (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}
      onPress={() => router.push(`/conteudo/${content.id}` as any)}
      activeOpacity={0.8}
    >
      <Image
        source={IMAGES[content.imageKey] ?? IMAGES.historia}
        style={[styles.image, compact && styles.imageCompact, { borderRadius: colors.radius }]}
        contentFit="cover"
      />
      <View style={styles.body}>
        <View style={styles.metaRow}>
          <View style={[styles.categoryBadge, { backgroundColor: content.category === 'Historia' ? '#1E3A5F' : '#2D1B33', borderRadius: 6 }]}>
            <Text style={[styles.categoryText, { color: content.category === 'Historia' ? '#5B9BD5' : '#B86CC8' }]}>
              {content.category === 'Historia' ? 'História' : 'Economia'}
            </Text>
          </View>
          {content.type === 'jindungo' && (
            <View style={[styles.jindungoBadge, { backgroundColor: colors.primary, borderRadius: 6 }]}>
              <MaterialCommunityIcons name="star-four-points" size={10} color="#fff" />
              <Text style={styles.jindungoText}>Jindungo</Text>
            </View>
          )}
          {isFavorite && <Feather name="heart" size={14} color={colors.primary} style={styles.heartIcon} />}
        </View>
        <Text style={[styles.title, { color: colors.foreground }]} numberOfLines={2}>{content.title}</Text>
        {!compact && (
          <Text style={[styles.summary, { color: colors.mutedForeground }]} numberOfLines={2}>{content.summary}</Text>
        )}
        <View style={styles.footer}>
          <Text style={[styles.author, { color: colors.mutedForeground }]}>{content.author}</Text>
          <View style={styles.views}>
            <Feather name="eye" size={12} color={colors.mutedForeground} />
            <Text style={[styles.viewsText, { color: colors.mutedForeground }]}>{content.views.toLocaleString()}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { borderWidth: 1, overflow: 'hidden', marginBottom: 12 },
  image: { width: '100%', height: 160 },
  imageCompact: { height: 120 },
  body: { padding: 14 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  categoryBadge: { paddingHorizontal: 8, paddingVertical: 3 },
  categoryText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  jindungoBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 3 },
  jindungoText: { fontSize: 11, fontFamily: 'Inter_600SemiBold', color: '#fff' },
  heartIcon: { marginLeft: 'auto' },
  title: { fontSize: 15, fontFamily: 'Inter_600SemiBold', lineHeight: 22, marginBottom: 6 },
  summary: { fontSize: 13, fontFamily: 'Inter_400Regular', lineHeight: 19, marginBottom: 10 },
  footer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  author: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  views: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  viewsText: { fontSize: 12, fontFamily: 'Inter_400Regular' },
});
