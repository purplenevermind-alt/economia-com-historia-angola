import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { UserRole } from '@/types';

const ROLE_LABELS: Record<UserRole, string> = {
  utilizador: 'Utilizador',
  moderador: 'Moderador',
  administrador: 'Administrador',
  super_administrador: 'Super Admin',
};

interface Props {
  role: UserRole;
  size?: 'sm' | 'md';
}

export function RoleBadge({ role, size = 'sm' }: Props) {
  const colors = useColors();
  const roleColor: Record<UserRole, string> = {
    utilizador: colors.roleUser,
    moderador: colors.roleModerador,
    administrador: colors.roleAdmin,
    super_administrador: colors.roleSuperAdmin,
  };
  const color = roleColor[role];

  return (
    <View style={[styles.badge, { backgroundColor: `${color}22`, borderColor: `${color}44`, borderRadius: 6, paddingHorizontal: size === 'md' ? 10 : 7, paddingVertical: size === 'md' ? 4 : 2 }]}>
      <Text style={[styles.text, { color, fontSize: size === 'md' ? 12 : 10, fontFamily: 'Inter_600SemiBold' }]}>
        {ROLE_LABELS[role]}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: { borderWidth: 1, alignSelf: 'flex-start' },
  text: {},
});
