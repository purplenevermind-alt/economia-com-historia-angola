import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Debate } from '@/types';

interface Props {
  debate: Debate;
  onPress?: () => void;
}

export function DebateCard({ debate, onPress }: Props) {
  const colors = useColors();

  function handlePress() {
    if (onPress) onPress();
    else router.push(`/debate/${debate.id}` as any);
  }

  return (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}
      onPress={handlePress}
      activeOpacity={0.8}
    >
      <View style={styles.header}>
        <View style={styles.badges}>
          <View style={[styles.typeBadge, { backgroundColor: debate.type === 'publico' ? '#1A3A20' : '#3A1A20', borderRadius: 6 }]}>
            <Feather name={debate.type === 'publico' ? 'globe' : 'lock'} size={10} color={debate.type === 'publico' ? '#2ECC71' : colors.primary} />
            <Text style={[styles.typeText, { color: debate.type === 'publico' ? '#2ECC71' : colors.primary }]}>
              {debate.type === 'publico' ? 'Público' : 'Privado'}
            </Text>
          </View>
          <View style={[styles.catBadge, { backgroundColor: colors.muted, borderRadius: 6 }]}>
            <Text style={[styles.catText, { color: colors.mutedForeground }]}>{debate.category}</Text>
          </View>
          {debate.isClosed && (
            <View style={[styles.closedBadge, { backgroundColor: '#3A2A1A', borderRadius: 6 }]}>
              <Text style={styles.closedText}>Encerrado</Text>
            </View>
          )}
        </View>
        <Text style={[styles.date, { color: colors.mutedForeground }]}>{new Date(debate.createdAt).toLocaleDateString('pt-AO')}</Text>
      </View>
      <Text style={[styles.title, { color: colors.foreground }]} numberOfLines={2}>{debate.title}</Text>
      <Text style={[styles.description, { color: colors.mutedForeground }]} numberOfLines={2}>{debate.description}</Text>
      <View style={styles.footer}>
        <Text style={[styles.creator, { color: colors.mutedForeground }]}>por {debate.creatorName}</Text>
        <View style={styles.stats}>
          <View style={styles.stat}>
            <Feather name="users" size={13} color={colors.mutedForeground} />
            <Text style={[styles.statText, { color: colors.mutedForeground }]}>{debate.membersCount}</Text>
          </View>
          <View style={styles.stat}>
            <Feather name="message-circle" size={13} color={colors.mutedForeground} />
            <Text style={[styles.statText, { color: colors.mutedForeground }]}>{debate.repliesCount}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { borderWidth: 1, padding: 14, marginBottom: 10 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  badges: { flexDirection: 'row', gap: 6 },
  typeBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 3 },
  typeText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  catBadge: { paddingHorizontal: 8, paddingVertical: 3 },
  catText: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  closedBadge: { paddingHorizontal: 8, paddingVertical: 3 },
  closedText: { color: '#E67E22', fontSize: 11, fontFamily: 'Inter_500Medium' },
  date: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  title: { fontSize: 15, fontFamily: 'Inter_600SemiBold', lineHeight: 21, marginBottom: 6 },
  description: { fontSize: 13, fontFamily: 'Inter_400Regular', lineHeight: 18, marginBottom: 10 },
  footer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  creator: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  stats: { flexDirection: 'row', gap: 12 },
  stat: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  statText: { fontSize: 12, fontFamily: 'Inter_500Medium' },
});
