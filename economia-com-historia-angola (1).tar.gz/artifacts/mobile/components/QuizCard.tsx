import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Quiz, QuizResult } from '@/types';

interface Props {
  quiz: Quiz;
  result?: QuizResult;
}

const DIFFICULTY_COLORS: Record<string, string> = {
  Facil: '#2ECC71',
  Medio: '#F39C12',
  Dificil: '#E74C3C',
};

const DIFFICULTY_LABELS: Record<string, string> = {
  Facil: 'Fácil',
  Medio: 'Médio',
  Dificil: 'Difícil',
};

export function QuizCard({ quiz, result }: Props) {
  const colors = useColors();
  const diffColor = DIFFICULTY_COLORS[quiz.difficulty] ?? colors.primary;

  return (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius }]}
      onPress={() => router.push(`/quiz/${quiz.id}` as any)}
      activeOpacity={0.8}
    >
      <View style={[styles.iconContainer, { backgroundColor: quiz.category === 'Historia' ? '#1E3A5F' : '#2D1B33', borderRadius: 12 }]}>
        <MaterialCommunityIcons
          name={quiz.category === 'Historia' ? 'book-open-page-variant' : 'chart-line'}
          size={28}
          color={quiz.category === 'Historia' ? '#5B9BD5' : '#B86CC8'}
        />
      </View>
      <View style={styles.body}>
        <View style={styles.topRow}>
          <View style={[styles.diffBadge, { backgroundColor: `${diffColor}22`, borderRadius: 6 }]}>
            <View style={[styles.diffDot, { backgroundColor: diffColor }]} />
            <Text style={[styles.diffText, { color: diffColor }]}>{DIFFICULTY_LABELS[quiz.difficulty]}</Text>
          </View>
          <View style={[styles.catBadge, { backgroundColor: colors.muted, borderRadius: 6 }]}>
            <Text style={[styles.catText, { color: colors.mutedForeground }]}>{quiz.category === 'Historia' ? 'História' : 'Economia'}</Text>
          </View>
        </View>
        <Text style={[styles.title, { color: colors.foreground }]} numberOfLines={2}>{quiz.title}</Text>
        <View style={styles.footer}>
          <View style={styles.questionsRow}>
            <Feather name="help-circle" size={13} color={colors.mutedForeground} />
            <Text style={[styles.questionsText, { color: colors.mutedForeground }]}>{quiz.questions.length} perguntas</Text>
          </View>
          {result ? (
            <View style={[styles.resultBadge, { backgroundColor: `${colors.success}22`, borderRadius: 6 }]}>
              <Feather name="check-circle" size={12} color={colors.success} />
              <Text style={[styles.resultText, { color: colors.success }]}>{Math.round((result.score / result.total) * 100)}%</Text>
            </View>
          ) : (
            <View style={[styles.startBadge, { backgroundColor: colors.primary, borderRadius: 6 }]}>
              <Text style={styles.startText}>Iniciar</Text>
            </View>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', padding: 14, borderWidth: 1, marginBottom: 10, gap: 12, alignItems: 'flex-start' },
  iconContainer: { width: 52, height: 52, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  body: { flex: 1 },
  topRow: { flexDirection: 'row', gap: 8, marginBottom: 6 },
  diffBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 8, paddingVertical: 3 },
  diffDot: { width: 6, height: 6, borderRadius: 3 },
  diffText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  catBadge: { paddingHorizontal: 8, paddingVertical: 3 },
  catText: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  title: { fontSize: 14, fontFamily: 'Inter_600SemiBold', lineHeight: 20, marginBottom: 10 },
  footer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  questionsRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  questionsText: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  resultBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 8, paddingVertical: 3 },
  resultText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  startBadge: { paddingHorizontal: 12, paddingVertical: 4 },
  startText: { color: '#fff', fontSize: 12, fontFamily: 'Inter_600SemiBold' },
});
