import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import React, { useState } from 'react';
import { Modal, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useColors } from '@/hooks/useColors';

interface Props {
  visible: boolean;
  contentTitle: string;
  hasPending: boolean;
  onRequest: () => void;
  onClose: () => void;
}

export function JindungoModal({ visible, contentTitle, hasPending, onRequest, onClose }: Props) {
  const colors = useColors();
  const [requested, setRequested] = useState(false);

  function handleRequest() {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    onRequest();
    setRequested(true);
  }

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={[styles.modal, { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius + 4 }]}>
          <View style={[styles.iconWrap, { backgroundColor: `${colors.primary}22`, borderRadius: 40 }]}>
            <MaterialCommunityIcons name="star-four-points" size={36} color={colors.primary} />
          </View>
          <View style={[styles.badge, { backgroundColor: colors.primary, borderRadius: 8 }]}>
            <Text style={styles.badgeText}>Conteúdo Jindungo</Text>
          </View>
          <Text style={[styles.title, { color: colors.foreground }]}>Autorização Necessária</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]} numberOfLines={3}>
            "{contentTitle}"
          </Text>
          <Text style={[styles.message, { color: colors.mutedForeground }]}>
            Este conteúdo requer autorização especial. Solicite o acesso e aguarde a aprovação de um administrador.
          </Text>

          {(requested || hasPending) ? (
            <View style={[styles.successBox, { backgroundColor: '#1A3A20', borderRadius: colors.radius }]}>
              <Feather name="check-circle" size={18} color="#2ECC71" />
              <Text style={styles.successText}>A sua solicitação foi enviada para análise.</Text>
            </View>
          ) : (
            <TouchableOpacity
              style={[styles.requestBtn, { backgroundColor: colors.primary, borderRadius: colors.radius }]}
              onPress={handleRequest}
              activeOpacity={0.8}
            >
              <Feather name="send" size={16} color="#fff" />
              <Text style={styles.requestBtnText}>Solicitar Acesso</Text>
            </TouchableOpacity>
          )}

          <TouchableOpacity style={styles.cancelBtn} onPress={onClose} activeOpacity={0.7}>
            <Text style={[styles.cancelText, { color: colors.mutedForeground }]}>Cancelar</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.75)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  modal: { width: '100%', borderWidth: 1, padding: 24, alignItems: 'center' },
  iconWrap: { width: 80, height: 80, alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  badge: { paddingHorizontal: 12, paddingVertical: 5, marginBottom: 14 },
  badgeText: { color: '#fff', fontSize: 12, fontFamily: 'Inter_700Bold', letterSpacing: 0.5 },
  title: { fontSize: 20, fontFamily: 'Inter_700Bold', marginBottom: 8, textAlign: 'center' },
  subtitle: { fontSize: 13, fontFamily: 'Inter_500Medium', textAlign: 'center', marginBottom: 12, fontStyle: 'italic' },
  message: { fontSize: 14, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 20, marginBottom: 20 },
  successBox: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14, width: '100%', marginBottom: 16 },
  successText: { color: '#2ECC71', fontFamily: 'Inter_500Medium', fontSize: 13, flex: 1 },
  requestBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, paddingVertical: 14, paddingHorizontal: 24, width: '100%', justifyContent: 'center', marginBottom: 12 },
  requestBtnText: { color: '#fff', fontFamily: 'Inter_700Bold', fontSize: 15 },
  cancelBtn: { paddingVertical: 8 },
  cancelText: { fontSize: 14, fontFamily: 'Inter_400Regular' },
});
