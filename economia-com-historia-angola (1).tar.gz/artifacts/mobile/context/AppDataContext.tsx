import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  AdminLog, Content, Debate, JindungoRequest,
  MembershipRequest, Quiz, QuizResult, Reply, User, UserRole,
} from '@/types';

interface AppDataContextType {
  contents: Content[];
  quizzes: Quiz[];
  debates: Debate[];
  replies: Reply[];
  favorites: string[];
  jindungoRequests: JindungoRequest[];
  membershipRequests: MembershipRequest[];
  adminLogs: AdminLog[];
  quizResults: QuizResult[];
  allUsers: User[];
  toggleFavorite: (contentId: string) => void;
  isFavorite: (contentId: string) => boolean;
  requestJindungoAccess: (contentId: string, userId: string, userName: string) => void;
  hasJindungoAccess: (contentId: string, userId: string) => boolean;
  hasPendingRequest: (contentId: string, userId: string) => boolean;
  approveJindungo: (requestId: string) => void;
  rejectJindungo: (requestId: string) => void;
  createDebate: (title: string, description: string, category: string, type: 'publico' | 'privado', creatorId: string, creatorName: string) => void;
  addReply: (debateId: string, userId: string, userName: string, userRole: string, content: string) => void;
  saveQuizResult: (result: QuizResult) => void;
  requestMembership: (debateId: string, debateTitle: string, userId: string, userName: string) => void;
  approveMembership: (requestId: string) => void;
  rejectMembership: (requestId: string) => void;
  getDebateMembers: (debateId: string) => string[];
  isDebateMember: (debateId: string, userId: string) => boolean;
  archiveContent: (contentId: string) => void;
  publishContent: (contentId: string) => void;
  closeDebate: (debateId: string) => void;
  changeUserRole: (userId: string, newRole: UserRole) => void;
  banUser: (userId: string) => void;
  platformStats: { totalUsers: number; totalContents: number; totalQuizzes: number; totalDebates: number };
}

const AppDataContext = createContext<AppDataContextType | null>(null);

const INITIAL_CONTENTS: Content[] = [
  {
    id: 'c1',
    title: 'A Independência de Angola e os Seus Impactos Económicos',
    summary: 'Uma análise profunda sobre como a independência de 1975 transformou a estrutura económica angolana e abriu novas perspectivas para o desenvolvimento nacional.',
    body: 'A independência de Angola, proclamada a 11 de Novembro de 1975, representou um marco histórico fundamental não apenas para o povo angolano, mas para todo o continente africano. Neste contexto, a transição do modelo colonial para um Estado independente trouxe consigo profundas transformações na estrutura económica do país...\n\nO petróleo, que desde a década de 1950 havia sido explorado pelos portugueses, passou a ser o principal motor da economia angolana independente. Com a nationalização das empresas petrolíferas e a criação da Sonangol em 1976, Angola consolidou o seu controlo sobre este recurso estratégico.\n\nParalelamente, o sector agrícola, que havia sustentado grande parte da economia colonial através do café e do algodão, enfrentou um período de reestruturação. A saída massiva dos colonos portugueses deixou um vazio técnico e administrativo que impactou significativamente a produção agrícola nas décadas seguintes.\n\nA Guerra Civil, que durou de 1975 a 2002, complicou ainda mais o desenvolvimento económico, desviando recursos fundamentais para o esforço de guerra e impedindo o investimento em infraestruturas essenciais. Contudo, mesmo neste período conturbado, as receitas petrolíferas continuaram a fluir, financiando tanto o conflito como as estruturas básicas do Estado.',
    author: 'Dr. António Kimbangu', category: 'Historia', type: 'publico', imageKey: 'historia', date: '2024-05-10', views: 1240, isArchived: false,
  },
  {
    id: 'c2',
    title: 'O Petróleo como Motor do Crescimento: Angola no Contexto Africano',
    summary: 'Como o ouro negro moldou décadas de crescimento económico e os desafios da diversificação económica num mundo em transição energética.',
    body: 'Angola é hoje o segundo maior produtor de petróleo da África Subsaariana, posição que consolidou ao longo de décadas de exploração intensiva. As reservas petrolíferas, estimadas em mais de 8 mil milhões de barris, têm sido o pilar fundamental das receitas do Estado angolano.\n\nA Sonangol, empresa estatal criada em 1976, desempenhou um papel central na gestão deste recurso estratégico. Com operações em mais de 15 países, a Sonangol cresceu para se tornar uma das maiores empresas africanas, sendo simultaneamente reguladora e operadora do sector petrolífero angolano.\n\nContudo, a excessiva dependência do petróleo criou vulnerabilidades estruturais na economia. Quando os preços do petróleo caíram drasticamente em 2014-2016, Angola entrou numa grave recessão económica, evidenciando a necessidade urgente de diversificação.',
    author: 'Engª Luísa Mbemba', category: 'Economia', type: 'publico', imageKey: 'economia', date: '2024-05-08', views: 980, isArchived: false,
  },
  {
    id: 'c3',
    title: 'O Reino do Kongo: Poder, Comércio e Diplomacia',
    summary: 'Uma viagem ao passado glorioso do Reino do Kongo, uma das maiores organizações políticas da África pré-colonial, com relações diplomáticas em toda a Europa.',
    body: 'O Reino do Kongo, fundado no século XIV, foi uma das mais sofisticadas organizações políticas da África Subsaariana. No seu apogeu, no século XVI, estendia-se por vastos territórios que hoje correspondem ao norte de Angola, ao Congo-Brazzaville, à República Democrática do Congo e ao Gabão.\n\nA estrutura política do Reino era notavelmente complexa. O Manikongo, rei supremo, governava através de uma hierarquia de governadores provinciais que administravam os diferentes territórios. Esta organização permitia uma administração eficiente de um território vastíssimo.\n\nO comércio era o coração do Reino do Kongo. Tecidos de rafia, marfim, escravos e produtos agrícolas eram trocados com os reinos vizinhos e, a partir do século XV, com os comerciantes europeus. A chegada dos portugueses em 1483, liderada por Diogo Cão, marcou o início de uma relação que seria simultaneamente frutífera e catastrófica.',
    author: 'Prof. Mateus Nzinga', category: 'Historia', type: 'jindungo', imageKey: 'historia', date: '2024-05-05', views: 2100, isArchived: false,
  },
  {
    id: 'c4',
    title: 'Diversificação Económica: O Caminho para a Sustentabilidade',
    summary: 'Análise das estratégias governamentais e privadas para reduzir a dependência do petróleo e desenvolver sectores como agricultura, turismo e tecnologia.',
    body: 'A dependência excessiva do petróleo tem sido um dos principais desafios da economia angolana. Com a volatilidade dos preços internacionais do crude, Angola tem enfrentado ciclos de expansão e contracção económica que dificultam o planeamento de longo prazo.\n\nO governo angolano lançou várias iniciativas para diversificar a economia: o Programa de Apoio à Produção, Diversificação das Exportações e Substituição das Importações (PRODESI) é um dos mais ambiciosos. Foca-se em impulsionar a produção agrícola, manufactureira e de serviços.\n\nO sector agrícola tem enorme potencial. Angola possui vastas terras férteis e recursos hídricos abundantes. O café angolano, que antes da independência tornava Angola o quarto maior produtor mundial, está a ser revitalizado com investimentos públicos e privados.',
    author: 'Dra. Filomena Cassule', category: 'Economia', type: 'publico', imageKey: 'economia', date: '2024-05-01', views: 756, isArchived: false,
  },
  {
    id: 'c5',
    title: 'A Rainha Nzinga: Resistência e Diplomacia no Século XVII',
    summary: 'A história extraordinária da rainha Nzinga Mbandi, símbolo da resistência angolana contra a colonização portuguesa e líder diplomática de extraordinária habilidade.',
    body: 'Ana de Sousa Nzinga Mbandi, conhecida simplesmente como Rainha Nzinga, é uma das figuras mais fascinantes e complexas da história africana. Nascida por volta de 1583, governou os reinos de Ndongo e Matamba durante décadas, tornando-se um símbolo universal de resistência e liderança.\n\nSua habilidade diplomática ficou evidente logo em 1622, quando foi enviada como embaixadora ao governador português João Correia de Sousa em Luanda. Conta a lenda que, ao não encontrar uma cadeira disponível (numa provocação deliberada), Nzinga ordenou a uma das suas servas que se ajoelhasse para servir de assento, demonstrando que não se inclinaria perante nenhum poder colonial.\n\nAo longo de décadas, Nzinga aliou-se aos holandeses, combateu os portugueses, negociou tratados e adaptou as suas alianças com extraordinária flexibilidade estratégica. Faleceu em 1663, aos 80 anos, ainda governando.',
    author: 'Prof. Esperança Kavungo', category: 'Historia', type: 'jindungo', imageKey: 'historia', date: '2024-04-28', views: 3400, isArchived: false,
  },
  {
    id: 'c6',
    title: 'Sistema Bancário Angolano: Evolução e Perspectivas',
    summary: 'Uma análise do desenvolvimento do sector bancário angolano desde a independência, com foco na regulação, inclusão financeira e digitalização.',
    body: 'O sector bancário angolano passou por transformações profundas desde a independência em 1975. Da banca estatizada dos primeiros anos à liberalização dos anos 1990, o sistema financeiro angolano reflecte a trajectória económica mais ampla do país.\n\nO Banco Nacional de Angola (BNA) é a autoridade monetária central, responsável pela política monetária e cambial, bem como pela supervisão das instituições financeiras. A sua independência operacional tem sido gradualmente reforçada ao longo dos anos.\n\nActualmente, Angola conta com mais de 20 bancos comerciais, liderados pelo Banco de Poupança e Crédito (BPC), Banco de Fomento Angola (BFA) e Banco Internacional de Crédito (BIC). A competição no sector tem impulsionado a inovação, especialmente nos serviços digitais e de mobile banking.',
    author: 'Dr. Paulo Neto', category: 'Economia', type: 'publico', imageKey: 'economia', date: '2024-04-25', views: 612, isArchived: false,
  },
  {
    id: 'c7',
    title: 'A Guerra Civil Angolana: Causas, Desenvolvimento e Legado',
    summary: 'Um estudo aprofundado sobre o conflito que devastou Angola durante 27 anos, as suas raízes históricas, os actores envolvidos e as marcas que deixou na sociedade.',
    body: 'A Guerra Civil Angolana (1975-2002) foi um dos conflitos mais devastadores da África contemporânea. Com mais de 500.000 mortos e milhões de deslocados, o conflito deixou cicatrizes profundas na sociedade angolana que ainda hoje são sentidas.\n\nAs raízes do conflito remontam ao período colonial, quando os movimentos de libertação — MPLA, FNLA e UNITA — competiam pelo controlo político. A independência não trouxe unidade, mas sim um conflito armado alimentado pela Guerra Fria, com a URSS e Cuba apoiando o MPLA, e os EUA e África do Sul apoiando a UNITA e a FNLA.\n\nO Acordo de Paz de Lusaka em 1994 tentou estabelecer uma transição, mas falhou. Só com a morte de Jonas Savimbi, líder da UNITA, em Fevereiro de 2002, é que o conflito chegou definitivamente ao fim, com a assinatura do Memorando de Entendimento de Luena.',
    author: 'Dr. Sebastião Luvualu', category: 'Historia', type: 'publico', imageKey: 'historia', date: '2024-04-20', views: 1890, isArchived: false,
  },
  {
    id: 'c8',
    title: 'Kwanza Digital: Angola na Vanguarda da Moeda Digital Africana',
    summary: 'Como Angola está a preparar a transição para uma moeda digital do Banco Central e o que isso significa para a inclusão financeira e a modernização económica.',
    body: 'O Banco Nacional de Angola (BNA) tem estado a estudar activamente a implementação de uma Moeda Digital do Banco Central (CBDC), o Kwanza Digital. Esta iniciativa insere-se numa tendência global de digitalização das moedas soberanas, com mais de 130 países a explorar CBDCs em diversas fases.\n\nO principal objectivo do Kwanza Digital é promover a inclusão financeira, permitindo que angolanos sem conta bancária possam participar na economia formal através de dispositivos móveis. Com uma taxa de bancarização ainda abaixo de 50%, este potencial é imenso.\n\nAlém da inclusão financeira, o Kwanza Digital poderá reduzir os custos das transacções, combater a economia informal e facilitar as remessas internacionais. Os desafios incluem a infraestrutura tecnológica, a literacia digital e a cibersegurança.',
    author: 'Engª Tatiana Ferreira', category: 'Economia', type: 'jindungo', imageKey: 'economia', date: '2024-04-15', views: 445, isArchived: false,
  },
];

const INITIAL_QUIZZES: Quiz[] = [
  {
    id: 'q1', title: 'Independência e Primeiros Anos', description: 'Teste os seus conhecimentos sobre a independência de Angola e os primeiros anos da república.', category: 'Historia', difficulty: 'Facil',
    questions: [
      { id: 'q1p1', question: 'Em que data Angola proclamou a sua independência?', options: ['11 de Novembro de 1975', '25 de Abril de 1974', '5 de Outubro de 1910', '1 de Janeiro de 1975'], correctAnswer: 0 },
      { id: 'q1p2', question: 'Qual foi o primeiro presidente de Angola?', options: ['Jonas Savimbi', 'Holden Roberto', 'Agostinho Neto', 'Eduardo dos Santos'], correctAnswer: 2 },
      { id: 'q1p3', question: 'Qual movimento declarou a independência em Luanda?', options: ['FNLA', 'UNITA', 'MPLA', 'FLEC'], correctAnswer: 2 },
      { id: 'q1p4', question: 'De que país se tornou Angola independente?', options: ['França', 'Reino Unido', 'Espanha', 'Portugal'], correctAnswer: 3 },
    ],
  },
  {
    id: 'q2', title: 'Economia do Petróleo', description: 'Quanto sabe sobre o sector petrolífero angolano e o seu impacto na economia nacional?', category: 'Economia', difficulty: 'Medio',
    questions: [
      { id: 'q2p1', question: 'Em que ano foi criada a Sonangol?', options: ['1975', '1976', '1980', '1985'], correctAnswer: 1 },
      { id: 'q2p2', question: 'Qual é a principal bacia petrolífera de Angola?', options: ['Bacia do Congo', 'Bacia do Kwanza', 'Bacia do Namibe', 'Bacia de Cabinda'], correctAnswer: 0 },
      { id: 'q2p3', question: 'Angola é membro de qual organização petrolífera?', options: ['OCDE', 'OPEP', 'SADC', 'União Africana'], correctAnswer: 1 },
      { id: 'q2p4', question: 'Qual percentagem do PIB angolano vem do petróleo (aprox.)?', options: ['20%', '35%', '50%', '65%'], correctAnswer: 2 },
    ],
  },
  {
    id: 'q3', title: 'O Reino do Kongo', description: 'Teste os seus conhecimentos sobre o poderoso Reino do Kongo e a sua história.', category: 'Historia', difficulty: 'Dificil',
    questions: [
      { id: 'q3p1', question: 'Quando foi fundado o Reino do Kongo?', options: ['Século XII', 'Século XIV', 'Século XVI', 'Século XVII'], correctAnswer: 1 },
      { id: 'q3p2', question: 'Qual era a capital do Reino do Kongo?', options: ['Luanda', 'Mbanza Kongo', 'Malebo', 'Matamba'], correctAnswer: 1 },
      { id: 'q3p3', question: 'O rei do Kongo era chamado de?', options: ['Manikongo', 'Mwene Mutapa', 'Askia', 'Obba'], correctAnswer: 0 },
      { id: 'q3p4', question: 'Qual era a principal mercadoria comercializada pelo Reino do Kongo com os europeus?', options: ['Ouro', 'Marfim', 'Escravos e tecidos', 'Especiarias'], correctAnswer: 2 },
    ],
  },
  {
    id: 'q4', title: 'Sistema Financeiro Angolano', description: 'Avalie os seus conhecimentos sobre o sistema bancário e financeiro de Angola.', category: 'Economia', difficulty: 'Medio',
    questions: [
      { id: 'q4p1', question: 'Qual é a moeda oficial de Angola?', options: ['Kwanza', 'Escudo', 'Franco', 'Rand'], correctAnswer: 0 },
      { id: 'q4p2', question: 'O BNA significa?', options: ['Banco Nacional Angolano', 'Banco Nacional de Angola', 'Banco Neto Angolano', 'Bolsa Nacional de Angola'], correctAnswer: 1 },
      { id: 'q4p3', question: 'Em que ano o Kwanza foi reintroduzido?', options: ['1990', '1995', '1999', '2000'], correctAnswer: 1 },
      { id: 'q4p4', question: 'Qual é o maior banco comercial de Angola?', options: ['BFA', 'BPC', 'BAI', 'BIC'], correctAnswer: 1 },
    ],
  },
  {
    id: 'q5', title: 'Rainha Nzinga e Resistência', description: 'Teste os seus conhecimentos sobre a lendária Rainha Nzinga e a resistência angolana.', category: 'Historia', difficulty: 'Facil',
    questions: [
      { id: 'q5p1', question: 'Qual era o nome completo da Rainha Nzinga?', options: ['Ana de Sousa Nzinga Mbandi', 'Maria Nzinga da Silva', 'Clara Nzinga Kavungo', 'Luísa Nzinga Ndongo'], correctAnswer: 0 },
      { id: 'q5p2', question: 'Quais reinos governou a Rainha Nzinga?', options: ['Kongo e Loango', 'Ndongo e Matamba', 'Lunda e Chokwe', 'Ovambo e Herero'], correctAnswer: 1 },
      { id: 'q5p3', question: 'Contra quem resistiu principalmente a Rainha Nzinga?', options: ['Holandeses', 'Britânicos', 'Franceses', 'Portugueses'], correctAnswer: 3 },
      { id: 'q5p4', question: 'Em que cidade assinou Nzinga um tratado com os portugueses?', options: ['Luanda', 'Mbanza Kongo', 'Benguela', 'Matamba'], correctAnswer: 0 },
    ],
  },
  {
    id: 'q6', title: 'Diversificação e Desenvolvimento', description: 'Avalie o seu conhecimento sobre as estratégias de diversificação económica de Angola.', category: 'Economia', difficulty: 'Dificil',
    questions: [
      { id: 'q6p1', question: 'Qual o principal produto agrícola de exportação antes do petróleo?', options: ['Algodão', 'Cacau', 'Café', 'Açúcar'], correctAnswer: 2 },
      { id: 'q6p2', question: 'O PDN é o Plano de Desenvolvimento?', options: ['Plano de Democracia Nacional', 'Plano de Desenvolvimento Nacional', 'Plano Diversificado Nacional', 'Plano de Distribuição Nacional'], correctAnswer: 1 },
      { id: 'q6p3', question: 'Qual sector Angola mais quer desenvolver após petróleo?', options: ['Mineração', 'Turismo e Agricultura', 'Indústria Pesada', 'Serviços Financeiros'], correctAnswer: 1 },
      { id: 'q6p4', question: 'O PRODESI é um programa de?', options: ['Saúde Pública', 'Apoio à Produção e Exportação', 'Educação Básica', 'Habitação Social'], correctAnswer: 1 },
    ],
  },
];

const INITIAL_DEBATES: Debate[] = [
  { id: 'd1', title: 'O Petróleo foi Bênção ou Maldição para Angola?', description: 'Debate sobre os impactos positivos e negativos da dependência petrolífera na economia e sociedade angolana.', category: 'Economia', type: 'publico', creatorId: 'user-1', creatorName: 'João Silva', membersCount: 24, repliesCount: 18, createdAt: '2024-05-09', isClosed: false },
  { id: 'd2', title: 'A Rainha Nzinga: Heroína ou Traidora?', description: 'Análise histórica e debate académico sobre o papel e legado da Rainha Nzinga na história de Angola.', category: 'Historia', type: 'publico', creatorId: 'mod-1', creatorName: 'Ana Moderadora', membersCount: 56, repliesCount: 43, createdAt: '2024-05-07', isClosed: false },
  { id: 'd3', title: 'Diversificação Económica: Por onde começar?', description: 'Discussão sobre as prioridades e estratégias para diversificar a economia angolana e reduzir a dependência do petróleo.', category: 'Economia', type: 'publico', creatorId: 'admin-1', creatorName: 'Carlos Administrador', membersCount: 38, repliesCount: 27, createdAt: '2024-05-05', isClosed: false },
  { id: 'd4', title: 'Grupo de Estudo: História Colonial Avançada', description: 'Grupo privado para discussão aprofundada de fontes primárias sobre o período colonial angolano.', category: 'Historia', type: 'privado', creatorId: 'mod-1', creatorName: 'Ana Moderadora', membersCount: 8, repliesCount: 62, createdAt: '2024-04-20', isClosed: false },
  { id: 'd5', title: 'O Legado do MPLA nos 50 Anos de Independência', description: 'Avaliação crítica e construtiva do papel do MPLA na construção do Estado angolano ao longo de cinco décadas.', category: 'Historia', type: 'publico', creatorId: 'user-1', creatorName: 'João Silva', membersCount: 71, repliesCount: 89, createdAt: '2024-04-15', isClosed: false },
  { id: 'd6', title: 'Câmbio e Inflação: Desafios do Kwanza', description: 'Análise técnica dos desafios monetários que Angola enfrenta e possíveis soluções para estabilizar o Kwanza.', category: 'Economia', type: 'privado', creatorId: 'admin-1', creatorName: 'Carlos Administrador', membersCount: 15, repliesCount: 34, createdAt: '2024-04-10', isClosed: true },
];

const INITIAL_REPLIES: Reply[] = [
  { id: 'r1', debateId: 'd1', userId: 'user-1', userName: 'João Silva', userRole: 'utilizador', content: 'Acredito que o petróleo foi uma bênção que infelizmente não foi bem gerida. As receitas poderiam ter diversificado a economia muito antes.', createdAt: '2024-05-09T10:30:00' },
  { id: 'r2', debateId: 'd1', userId: 'mod-1', userName: 'Ana Moderadora', userRole: 'moderador', content: 'A chamada "maldição dos recursos" é um fenómeno bem documentado. Angola não está sozinha neste desafio - veja a Nigéria, a Venezuela...', createdAt: '2024-05-09T11:15:00' },
  { id: 'r3', debateId: 'd1', userId: 'admin-1', userName: 'Carlos Administrador', userRole: 'administrador', content: 'Sem o petróleo, Angola não teria recuperado tão rapidamente da guerra civil. É necessário avaliar o contexto histórico.', createdAt: '2024-05-09T14:00:00' },
  { id: 'r4', debateId: 'd2', userId: 'mod-1', userName: 'Ana Moderadora', userRole: 'moderador', content: 'Nzinga foi definitivamente uma heroína. A sua capacidade diplomática e militar era extraordinária para a sua época.', createdAt: '2024-05-07T09:00:00' },
  { id: 'r5', debateId: 'd2', userId: 'user-1', userName: 'João Silva', userRole: 'utilizador', content: 'É uma figura complexa. A sua aliança com os holandeses para combater os portugueses mostra uma visão política sofisticada.', createdAt: '2024-05-07T10:30:00' },
];

const INITIAL_ADMIN_LOGS: AdminLog[] = [
  { id: 'l1', adminId: 'admin-1', adminName: 'Carlos Administrador', action: 'aprovacao_jindungo', details: 'Acesso Jindungo aprovado para: O Reino do Kongo — Mateus Nzinga', createdAt: '2024-05-09T08:00:00' },
  { id: 'l2', adminId: 'super-1', adminName: 'Super Administrador', action: 'promocao_utilizador', details: 'Utilizador promovido a Moderador: Ana Moderadora', createdAt: '2024-05-08T14:00:00' },
  { id: 'l3', adminId: 'admin-1', adminName: 'Carlos Administrador', action: 'arquivar_conteudo', details: 'Conteúdo arquivado: Kwanza Digital (revisão em curso)', createdAt: '2024-05-08T09:30:00' },
];

const INITIAL_USERS: User[] = [
  { id: 'super-1', name: 'Super Administrador', email: 'super@ecomhistoria.ao', role: 'super_administrador', quizzesRealizados: 45, debatesCriados: 12, pontuacaoTotal: 980, createdAt: '2024-01-01', suspended: false },
  { id: 'admin-1', name: 'Carlos Administrador', email: 'admin@ecomhistoria.ao', role: 'administrador', quizzesRealizados: 32, debatesCriados: 8, pontuacaoTotal: 720, createdAt: '2024-02-01', suspended: false },
  { id: 'mod-1', name: 'Ana Moderadora', email: 'mod@ecomhistoria.ao', role: 'moderador', quizzesRealizados: 28, debatesCriados: 15, pontuacaoTotal: 540, createdAt: '2024-03-01', suspended: false },
  { id: 'user-1', name: 'João Silva', email: 'joao@email.com', role: 'utilizador', quizzesRealizados: 5, debatesCriados: 2, pontuacaoTotal: 150, createdAt: '2024-04-01', suspended: false },
  { id: 'user-2', name: 'Maria Santos', email: 'maria@email.com', role: 'utilizador', quizzesRealizados: 12, debatesCriados: 3, pontuacaoTotal: 280, createdAt: '2024-04-15', suspended: false },
  { id: 'user-3', name: 'Pedro Neto', email: 'pedro@email.com', role: 'utilizador', quizzesRealizados: 8, debatesCriados: 1, pontuacaoTotal: 190, createdAt: '2024-05-01', suspended: false },
];

export function AppDataProvider({ children }: { children: React.ReactNode }) {
  const [contents, setContents] = useState<Content[]>(INITIAL_CONTENTS);
  const [debates, setDebates] = useState<Debate[]>(INITIAL_DEBATES);
  const [replies, setReplies] = useState<Reply[]>(INITIAL_REPLIES);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [jindungoRequests, setJindungoRequests] = useState<JindungoRequest[]>([]);
  const [membershipRequests, setMembershipRequests] = useState<MembershipRequest[]>([]);
  const [debateMembers, setDebateMembers] = useState<Record<string, string[]>>({ d4: ['mod-1'], d6: ['admin-1'] });
  const [adminLogs, setAdminLogs] = useState<AdminLog[]>(INITIAL_ADMIN_LOGS);
  const [quizResults, setQuizResults] = useState<QuizResult[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>(INITIAL_USERS);

  useEffect(() => {
    AsyncStorage.getItem('favorites').then(v => { if (v) setFavorites(JSON.parse(v)); });
    AsyncStorage.getItem('jindungoRequests').then(v => { if (v) setJindungoRequests(JSON.parse(v)); });
    AsyncStorage.getItem('quizResults').then(v => { if (v) setQuizResults(JSON.parse(v)); });
  }, []);

  function addAdminLog(adminId: string, adminName: string, action: string, details: string) {
    const log: AdminLog = { id: `l-${Date.now()}`, adminId, adminName, action, details, createdAt: new Date().toISOString() };
    setAdminLogs(prev => [log, ...prev]);
  }

  function toggleFavorite(contentId: string) {
    setFavorites(prev => {
      const next = prev.includes(contentId) ? prev.filter(id => id !== contentId) : [...prev, contentId];
      AsyncStorage.setItem('favorites', JSON.stringify(next));
      return next;
    });
  }

  function isFavorite(contentId: string) { return favorites.includes(contentId); }

  function requestJindungoAccess(contentId: string, userId: string, userName: string) {
    const content = contents.find(c => c.id === contentId);
    if (!content) return;
    const req: JindungoRequest = {
      id: `jr-${Date.now()}`, userId, userName, contentId, contentTitle: content.title, status: 'pendente', requestedAt: new Date().toISOString(),
    };
    setJindungoRequests(prev => {
      const next = [...prev, req];
      AsyncStorage.setItem('jindungoRequests', JSON.stringify(next));
      return next;
    });
  }

  function hasJindungoAccess(contentId: string, userId: string) {
    return jindungoRequests.some(r => r.contentId === contentId && r.userId === userId && r.status === 'aprovada');
  }

  function hasPendingRequest(contentId: string, userId: string) {
    return jindungoRequests.some(r => r.contentId === contentId && r.userId === userId && r.status === 'pendente');
  }

  function approveJindungo(requestId: string) {
    const req = jindungoRequests.find(r => r.id === requestId);
    setJindungoRequests(prev => {
      const next = prev.map(r => r.id === requestId ? { ...r, status: 'aprovada' as const } : r);
      AsyncStorage.setItem('jindungoRequests', JSON.stringify(next));
      return next;
    });
    if (req) addAdminLog('admin', 'Administrador', 'aprovacao_jindungo', `Acesso Jindungo aprovado para: ${req.contentTitle} — ${req.userName}`);
  }

  function rejectJindungo(requestId: string) {
    const req = jindungoRequests.find(r => r.id === requestId);
    setJindungoRequests(prev => {
      const next = prev.map(r => r.id === requestId ? { ...r, status: 'rejeitada' as const } : r);
      AsyncStorage.setItem('jindungoRequests', JSON.stringify(next));
      return next;
    });
    if (req) addAdminLog('admin', 'Administrador', 'rejeicao_jindungo', `Acesso Jindungo rejeitado para: ${req.contentTitle} — ${req.userName}`);
  }

  function createDebate(title: string, description: string, category: string, type: 'publico' | 'privado', creatorId: string, creatorName: string) {
    const debate: Debate = {
      id: `d-${Date.now()}`, title, description, category, type, creatorId, creatorName, membersCount: 1, repliesCount: 0, createdAt: new Date().toISOString(), isClosed: false,
    };
    setDebates(prev => [debate, ...prev]);
    setDebateMembers(prev => ({ ...prev, [debate.id]: [creatorId] }));
  }

  function addReply(debateId: string, userId: string, userName: string, userRole: string, content: string) {
    const reply: Reply = { id: `r-${Date.now()}`, debateId, userId, userName, userRole: userRole as UserRole, content, createdAt: new Date().toISOString() };
    setReplies(prev => [...prev, reply]);
    setDebates(prev => prev.map(d => d.id === debateId ? { ...d, repliesCount: d.repliesCount + 1 } : d));
  }

  function saveQuizResult(result: QuizResult) {
    setQuizResults(prev => {
      const next = [...prev.filter(r => r.quizId !== result.quizId), result];
      AsyncStorage.setItem('quizResults', JSON.stringify(next));
      return next;
    });
  }

  function requestMembership(debateId: string, debateTitle: string, userId: string, userName: string) {
    const req: MembershipRequest = { id: `mr-${Date.now()}`, debateId, debateTitle, userId, userName, status: 'pendente', requestedAt: new Date().toISOString() };
    setMembershipRequests(prev => [...prev, req]);
  }

  function approveMembership(requestId: string) {
    const req = membershipRequests.find(r => r.id === requestId);
    if (!req) return;
    setMembershipRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: 'aprovada' as const } : r));
    setDebateMembers(prev => ({ ...prev, [req.debateId]: [...(prev[req.debateId] ?? []), req.userId] }));
    setDebates(prev => prev.map(d => d.id === req.debateId ? { ...d, membersCount: d.membersCount + 1 } : d));
    addAdminLog('admin', 'Administrador', 'aprovacao_membro', `Entrada no fórum aprovada para: ${req.userName} — ${req.debateTitle}`);
  }

  function rejectMembership(requestId: string) {
    const req = membershipRequests.find(r => r.id === requestId);
    setMembershipRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: 'rejeitada' as const } : r));
    if (req) addAdminLog('admin', 'Administrador', 'rejeicao_membro', `Entrada no fórum rejeitada para: ${req.userName} — ${req.debateTitle}`);
  }

  function getDebateMembers(debateId: string) { return debateMembers[debateId] ?? []; }
  function isDebateMember(debateId: string, userId: string) { return (debateMembers[debateId] ?? []).includes(userId); }

  function archiveContent(contentId: string) {
    setContents(prev => prev.map(c => c.id === contentId ? { ...c, isArchived: true } : c));
    const c = contents.find(x => x.id === contentId);
    if (c) addAdminLog('admin', 'Administrador', 'arquivar_conteudo', `Conteúdo arquivado: ${c.title}`);
  }

  function publishContent(contentId: string) {
    setContents(prev => prev.map(c => c.id === contentId ? { ...c, isArchived: false } : c));
    const c = contents.find(x => x.id === contentId);
    if (c) addAdminLog('admin', 'Administrador', 'restaurar_conteudo', `Conteúdo restaurado: ${c.title}`);
  }

  function closeDebate(debateId: string) {
    setDebates(prev => prev.map(d => d.id === debateId ? { ...d, isClosed: true } : d));
    const d = debates.find(x => x.id === debateId);
    if (d) addAdminLog('admin', 'Administrador', 'encerrar_debate', `Debate encerrado: ${d.title}`);
  }

  function changeUserRole(userId: string, newRole: UserRole) {
    const u = allUsers.find(x => x.id === userId);
    setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, role: newRole } : u));
    if (u) addAdminLog('admin', 'Administrador', 'promocao_utilizador', `${u.name} promovido(a) a ${newRole.replace('_', ' ')}`);
  }

  function banUser(userId: string) {
    const u = allUsers.find(x => x.id === userId);
    setAllUsers(prev => prev.map(u => u.id === userId ? { ...u, isBanned: true, suspended: true } : u));
    if (u) addAdminLog('admin', 'Administrador', 'ban_utilizador', `Utilizador banido: ${u.name} (${u.email})`);
  }

  const platformStats = {
    totalUsers: allUsers.length,
    totalContents: contents.length,
    totalQuizzes: INITIAL_QUIZZES.length,
    totalDebates: debates.length,
  };

  return (
    <AppDataContext.Provider value={{
      contents, quizzes: INITIAL_QUIZZES, debates, replies, favorites,
      jindungoRequests, membershipRequests, adminLogs, quizResults, allUsers,
      toggleFavorite, isFavorite,
      requestJindungoAccess, hasJindungoAccess, hasPendingRequest,
      approveJindungo, rejectJindungo,
      createDebate, addReply, saveQuizResult,
      requestMembership, approveMembership, rejectMembership,
      getDebateMembers, isDebateMember,
      archiveContent, publishContent, closeDebate, changeUserRole, banUser,
      platformStats,
    }}>
      {children}
    </AppDataContext.Provider>
  );
}

export function useAppData() {
  const ctx = useContext(AppDataContext);
  if (!ctx) throw new Error('useAppData must be used within AppDataProvider');
  return ctx;
}
