import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, UserRole } from '@/types';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  isModerador: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

const MOCK_USERS: (User & { password: string })[] = [
  {
    id: 'super-1',
    name: 'Super Administrador',
    email: 'super@ecomhistoria.ao',
    password: 'super123',
    role: 'super_administrador',
    quizzesRealizados: 45,
    debatesCriados: 12,
    pontuacaoTotal: 980,
    createdAt: '2024-01-01',
    suspended: false,
  },
  {
    id: 'admin-1',
    name: 'Carlos Administrador',
    email: 'admin@ecomhistoria.ao',
    password: 'admin123',
    role: 'administrador',
    quizzesRealizados: 32,
    debatesCriados: 8,
    pontuacaoTotal: 720,
    createdAt: '2024-02-01',
    suspended: false,
  },
  {
    id: 'mod-1',
    name: 'Ana Moderadora',
    email: 'mod@ecomhistoria.ao',
    password: 'mod123',
    role: 'moderador',
    quizzesRealizados: 28,
    debatesCriados: 15,
    pontuacaoTotal: 540,
    createdAt: '2024-03-01',
    suspended: false,
  },
  {
    id: 'user-1',
    name: 'João Silva',
    email: 'joao@email.com',
    password: '123456',
    role: 'utilizador',
    quizzesRealizados: 12,
    debatesCriados: 3,
    pontuacaoTotal: 240,
    createdAt: '2024-04-01',
    suspended: false,
  },
];

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [registeredUsers, setRegisteredUsers] = useState<(User & { password: string })[]>(MOCK_USERS);

  useEffect(() => {
    loadUser();
  }, []);

  async function loadUser() {
    try {
      const stored = await AsyncStorage.getItem('auth_user');
      if (stored) {
        setUser(JSON.parse(stored));
      }
    } catch {
      // ignore
    } finally {
      setIsLoading(false);
    }
  }

  async function login(email: string, password: string) {
    const found = registeredUsers.find(
      u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );
    if (!found) {
      return { success: false, error: 'Email ou palavra-passe incorretos.' };
    }
    if (found.suspended) {
      return { success: false, error: 'Conta suspensa. Contacte o administrador.' };
    }
    const { password: _, ...userData } = found;
    await AsyncStorage.setItem('auth_user', JSON.stringify(userData));
    setUser(userData);
    return { success: true };
  }

  async function register(name: string, email: string, password: string) {
    const exists = registeredUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (exists) {
      return { success: false, error: 'Este email já está registado.' };
    }
    const newUser: User & { password: string } = {
      id: `user-${Date.now()}`,
      name,
      email,
      password,
      role: 'utilizador',
      quizzesRealizados: 0,
      debatesCriados: 0,
      pontuacaoTotal: 0,
      createdAt: new Date().toISOString().split('T')[0],
      suspended: false,
    };
    setRegisteredUsers(prev => [...prev, newUser]);
    const { password: _, ...userData } = newUser;
    await AsyncStorage.setItem('auth_user', JSON.stringify(userData));
    setUser(userData);
    return { success: true };
  }

  async function logout() {
    await AsyncStorage.removeItem('auth_user');
    setUser(null);
  }

  async function updateProfile(data: Partial<User>) {
    if (!user) return;
    const updated = { ...user, ...data };
    await AsyncStorage.setItem('auth_user', JSON.stringify(updated));
    setUser(updated);
  }

  const isAdmin = user?.role === 'administrador' || user?.role === 'super_administrador';
  const isSuperAdmin = user?.role === 'super_administrador';
  const isModerador = user?.role === 'moderador' || isAdmin;

  return (
    <AuthContext.Provider value={{ user, isLoading, login, register, logout, updateProfile, isAdmin, isSuperAdmin, isModerador }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
