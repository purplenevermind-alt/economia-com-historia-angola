export type UserRole = 'utilizador' | 'moderador' | 'administrador' | 'super_administrador';
export type ContentCategory = 'Historia' | 'Economia';
export type ContentType = 'publico' | 'jindungo';
export type QuizDifficulty = 'Facil' | 'Medio' | 'Dificil';
export type DebateType = 'publico' | 'privado';
export type RequestStatus = 'pendente' | 'aprovada' | 'rejeitada';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  quizzesRealizados: number;
  debatesCriados: number;
  pontuacaoTotal: number;
  createdAt: string;
  suspended: boolean;
  isBanned?: boolean;
}

export interface Content {
  id: string;
  title: string;
  summary: string;
  body: string;
  author: string;
  category: ContentCategory;
  type: ContentType;
  imageKey: string;
  date: string;
  views: number;
  isArchived?: boolean;
}

export interface JindungoRequest {
  id: string;
  userId: string;
  userName: string;
  contentId: string;
  contentTitle: string;
  status: RequestStatus;
  requestedAt: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface Quiz {
  id: string;
  title: string;
  description: string;
  category: ContentCategory;
  difficulty: QuizDifficulty;
  questions: QuizQuestion[];
}

export interface QuizResult {
  quizId: string;
  score: number;
  total: number;
  completedAt: string;
}

export interface Debate {
  id: string;
  title: string;
  description: string;
  category: string;
  type: DebateType;
  creatorId: string;
  creatorName: string;
  membersCount: number;
  repliesCount: number;
  createdAt: string;
  isClosed: boolean;
}

export interface Reply {
  id: string;
  debateId: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  content: string;
  createdAt: string;
}

export interface MembershipRequest {
  id: string;
  debateId: string;
  debateTitle: string;
  userId: string;
  userName: string;
  status: RequestStatus;
  requestedAt: string;
}

export interface AdminLog {
  id: string;
  adminId: string;
  adminName: string;
  action: string;
  details: string;
  createdAt: string;
}
